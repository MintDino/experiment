# Experiment Mod Architecture (Minecraft 26.3)

## 1. Transactional State Lifecycle

```
[Start Session] 
       │
       ▼
[Write WAL Transaction Marker to Disk]
       │
       ▼
[Lazy Snapshot Engine] ──(Captures blocks/entities prior to mutation)
       │
       ▼
[Active Sandbox Gameplay] (Redstone, TNT, Fluid, Pistons, Inventory transfers)
       │
  ┌────┴───────────────────────────┐
  ▼                                ▼
[Commit Engine]              [Rollback Engine]
  │                                │
  ├─ Delete WAL Marker             ├─ Restore BlockStates
  ├─ Finalize World                ├─ Restore BlockEntity NBT (Chests/Hoppers)
  └─ Release Memory                ├─ Kill Spawned Mobs/Items
                                   ├─ Respawn Baseline Entities
                                   ├─ Sync Chunk Packets to Clients
                                   └─ Delete WAL Marker
```

## 2. Crash Recovery Protocol

The mod implements a Write-Ahead Log (WAL) located at `<world>/experiment_journal/session_<uuid>.wal`.
- **Pre-Execution:** Before any block mutation occurs, the active session boundary is persisted.
- **Interruption Recovery:** On `ServerLifecycleEvents.SERVER_STARTING`, `TransactionJournal.performCrashRecoveryCheck()` scans for unclosed `.wal` markers. If detected, it automatically executes a deterministic rollback or repairs dirty chunks.

## 3. Multiplayer Authorization

- Client sends `c2s_start`, `c2s_commit`, `c2s_discard`, `c2s_checkpoint`.
- Server validates that the player is within authorized bounds and holds host/operator permissions.
- State is strictly server-authoritative; client cannot fabricate snapshot state.
