# Changelog — Experiment Mod

## [1.0.0] - 2026-09-27
### Target: Minecraft Java Edition 26.3

#### Added
- Initial release for Minecraft 26.3 with Fabric Loader 0.18.2+ and Fabric API 0.125.0+26.3.
- Authoritative lazy snapshot engine capturing blocks, block entities, inventories, entities, and fluids.
- Real-time diff calculation and change categorization.
- Safe rollback engine with entity despawn/respawn and inventory reconstitution.
- Permanent commit engine with memory cleanup.
- Checkpoint manager with intermediate snapshot save and restore.
- Transaction write-ahead log (WAL) for guaranteed crash recovery.
- Full server-authoritative multiplayer networking with permission validation.
- Minecraft 26.3 GameTest integration test matrix covering TNT, redstone, fluids, chests, and crash recovery.
- Minecraft-native UI screens with Mint Dino jade/mint styling.
