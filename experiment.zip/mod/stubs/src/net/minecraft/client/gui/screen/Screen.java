package net.minecraft.client.gui.screen;
import net.minecraft.text.Text;
import net.minecraft.client.gui.DrawContext;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
public class Screen {
    public int width, height;
    public TextRenderer textRenderer = new TextRenderer();
    public ClientTickEvents.Client client;
    public Screen(Text t){}
    protected void init(){}
    public void render(DrawContext c, int mX, int mY, float d){}
    public void close(){}
    protected <T> T addDrawableChild(T w){return w;}
    public static class TextRenderer {}
}
