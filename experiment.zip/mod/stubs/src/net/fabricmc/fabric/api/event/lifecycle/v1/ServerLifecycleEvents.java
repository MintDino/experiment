package net.fabricmc.fabric.api.event.lifecycle.v1;
import net.minecraft.server.MinecraftServer;
public interface ServerLifecycleEvents {
    interface ServerStarting { void onServerStarting(MinecraftServer s); }
    interface ServerStopping { void onServerStopping(MinecraftServer s); }
    class EventStarting { public void register(ServerStarting s){} }
    class EventStopping { public void register(ServerStopping s){} }
    EventStarting SERVER_STARTING = new EventStarting();
    EventStopping SERVER_STOPPING = new EventStopping();
}
