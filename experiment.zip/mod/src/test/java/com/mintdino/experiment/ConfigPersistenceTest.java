package com.mintdino.experiment;

import com.mintdino.experiment.config.ExperimentConfig;
import java.io.File;
import java.nio.file.Files;

public class ConfigPersistenceTest {
    public static void main(String[] args) throws Exception {
        System.out.println("Testing Configuration Persistence for Minecraft 26.3...");

        File configFile = new File("config/experiment.json");
        configFile.getParentFile().mkdirs();

        // 1. Instantiate and modify
        ExperimentConfig config = new ExperimentConfig();
        config.setDefaultRadius(32);
        config.setMaxRadius(128);
        config.setMaxCheckpoints(20);
        config.setShowHud(false);
        config.setShowConfirmationPrompts(true);
        config.save();

        assert configFile.exists() : "config/experiment.json was not created!";

        // 2. Read directly from disk
        String content = Files.readString(configFile.toPath());
        System.out.println("Persistent JSON from disk:\n" + content);

        assert content.contains("\"defaultRadius\": 32") : "defaultRadius did not persist!";
        assert content.contains("\"maxRadius\": 128") : "maxRadius did not persist!";
        assert content.contains("\"maxCheckpoints\": 20") : "maxCheckpoints did not persist!";
        assert content.contains("\"showHud\": false") : "showHud did not persist!";
        assert content.contains("\"showConfirmationPrompts\": true") : "showConfirmationPrompts did not persist!";

        System.out.println("PASS: All 5 settings successfully written and verified persistent on disk.");
    }
}
