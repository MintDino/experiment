package com.mintdino.experiment;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

public class SnapshotDiffTest {

    @Test
    @DisplayName("Diff engine detects added, removed and altered states accurately")
    void testDiffCalculation() {
        Set<String> baseline = new HashSet<>(Arrays.asList("block_0_0_0:stone", "block_0_1_0:dirt"));
        Set<String> current = new HashSet<>(Arrays.asList("block_0_0_0:diamond_block", "block_0_1_0:dirt", "block_0_2_0:tnt"));

        Set<String> modifiedOrAdded = new HashSet<>(current);
        modifiedOrAdded.removeAll(baseline);

        assertTrue(modifiedOrAdded.contains("block_0_0_0:diamond_block"));
        assertTrue(modifiedOrAdded.contains("block_0_2_0:tnt"));
        assertEquals(2, modifiedOrAdded.size());
    }

    @Test
    @DisplayName("Checkpoint restore stack preserves chronological snapshots")
    void testCheckpointStackOrdering() {
        Map<String, String> checkpoints = new LinkedHashMap<>();
        checkpoints.put("cp_initial", "state_1");
        checkpoints.put("cp_blast", "state_2");

        assertTrue(checkpoints.containsKey("cp_initial"));
        assertEquals("state_1", checkpoints.get("cp_initial"));
        assertEquals(2, checkpoints.size());
    }
}
