package com.mintdino.experiment.gametest;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentSession;
import com.mintdino.experiment.core.SessionManager;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.BlockPos;

/**
 * Authoritative Minecraft Java Edition 26.3 GameTest Suite for Experiment.
 * Verifies the full integration test matrix with deterministic baseline assertion.
 */
public class ExperimentIntegrationTestMatrix implements FabricGameTest {

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testBasicBlockPlaceDiscard(TestContext context) {
        BlockPos testPos = new BlockPos(2, 2, 2);
        context.setBlockState(testPos, Blocks.STONE.getDefaultState());

        SessionManager manager = ExperimentMod.getInstance().getSessionManager();
        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "TestBot", context.getWorld(), testPos, 8, 8
        );

        // Place new block
        session.getSnapshotEngine().captureBlockBeforeChange(testPos);
        context.setBlockState(testPos, Blocks.DIAMOND_BLOCK.getDefaultState());
        context.checkBlock(testPos, state -> state.isOf(Blocks.DIAMOND_BLOCK), "Block should be diamond block");

        // Discard
        session.discard();
        context.checkBlock(testPos, state -> state.isOf(Blocks.STONE), "Block must be restored to stone after discard");
        context.complete();
    }

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testBasicBlockPlaceCommit(TestContext context) {
        BlockPos testPos = new BlockPos(2, 2, 2);
        context.setBlockState(testPos, Blocks.STONE.getDefaultState());

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "TestBot", context.getWorld(), testPos, 8, 8
        );

        session.getSnapshotEngine().captureBlockBeforeChange(testPos);
        context.setBlockState(testPos, Blocks.EMERALD_BLOCK.getDefaultState());

        session.commit();
        context.checkBlock(testPos, state -> state.isOf(Blocks.EMERALD_BLOCK), "Block must remain emerald after commit");
        context.complete();
    }

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testTntExplosionDiscard(TestContext context) {
        BlockPos center = new BlockPos(3, 2, 3);
        // Build a 3x3 stone bunker
        for (int x = 1; x <= 5; x++) {
            for (int z = 1; z <= 5; z++) {
                context.setBlockState(new BlockPos(x, 1, z), Blocks.STONE.getDefaultState());
            }
        }

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "TntTester", context.getWorld(), center, 8, 8
        );

        // Capture bunker blocks
        for (int x = 1; x <= 5; x++) {
            for (int z = 1; z <= 5; z++) {
                session.getSnapshotEngine().captureBlockBeforeChange(new BlockPos(x, 1, z));
            }
        }

        // Simulate explosion destroying bunker floor
        for (int x = 2; x <= 4; x++) {
            for (int z = 2; z <= 4; z++) {
                context.setBlockState(new BlockPos(x, 1, z), Blocks.AIR.getDefaultState());
            }
        }

        // Discard
        session.discard();

        // Verify full bunker restoration
        for (int x = 1; x <= 5; x++) {
            for (int z = 1; z <= 5; z++) {
                context.checkBlock(new BlockPos(x, 1, z), state -> state.isOf(Blocks.STONE), "Bunker stone restored");
            }
        }
        context.complete();
    }

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testContainerInventoryDiscard(TestContext context) {
        BlockPos chestPos = new BlockPos(2, 2, 2);
        context.setBlockState(chestPos, Blocks.CHEST.getDefaultState());

        ChestBlockEntity chest = (ChestBlockEntity) context.getBlockEntity(chestPos);
        chest.setStack(0, new ItemStack(Items.DIAMOND, 64));
        chest.setStack(1, new ItemStack(Items.NETHERITE_INGOT, 16));

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "ChestTester", context.getWorld(), chestPos, 8, 8
        );
        session.getSnapshotEngine().captureBlockBeforeChange(chestPos);

        // Steal items from chest
        chest.clear();
        context.assertTrue(chest.isEmpty(), "Chest should be empty during test");

        // Discard session
        session.discard();

        ChestBlockEntity restoredChest = (ChestBlockEntity) context.getBlockEntity(chestPos);
        context.assertTrue(restoredChest.getStack(0).isOf(Items.DIAMOND) && restoredChest.getStack(0).getCount() == 64,
                "Chest must have 64 diamonds restored");
        context.assertTrue(restoredChest.getStack(1).isOf(Items.NETHERITE_INGOT) && restoredChest.getStack(1).getCount() == 16,
                "Chest must have 16 netherite ingots restored");
        context.complete();
    }

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testFluidFlowDiscard(TestContext context) {
        BlockPos waterPos = new BlockPos(3, 2, 3);
        context.setBlockState(waterPos, Blocks.AIR.getDefaultState());

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "FluidTester", context.getWorld(), waterPos, 8, 8
        );
        session.getSnapshotEngine().captureBlockBeforeChange(waterPos);

        // Place water
        context.setBlockState(waterPos, Blocks.WATER.getDefaultState());
        context.checkBlock(waterPos, state -> state.isOf(Blocks.WATER), "Water placed");

        session.discard();
        context.checkBlock(waterPos, state -> state.isOf(Blocks.AIR), "Water completely removed after discard");
        context.complete();
    }

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testCheckpointStack(TestContext context) {
        BlockPos pos = new BlockPos(2, 2, 2);
        context.setBlockState(pos, Blocks.DIRT.getDefaultState());

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "CheckpointTester", context.getWorld(), pos, 8, 8
        );
        session.getSnapshotEngine().captureBlockBeforeChange(pos);

        // Modify 1
        context.setBlockState(pos, Blocks.COBBLESTONE.getDefaultState());
        session.getCheckpointManager().createCheckpoint("cp_cobble");

        // Modify 2
        context.setBlockState(pos, Blocks.OBSIDIAN.getDefaultState());

        // Restore cp_cobble
        session.getCheckpointManager().restoreCheckpoint("cp_cobble");
        context.checkBlock(pos, state -> state.isOf(Blocks.COBBLESTONE), "Restored to checkpoint cobblestone");

        // Discard to baseline
        session.discard();
        context.checkBlock(pos, state -> state.isOf(Blocks.DIRT), "Restored to baseline dirt");
        context.complete();
    }
}
