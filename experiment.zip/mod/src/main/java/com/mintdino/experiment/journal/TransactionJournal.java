package com.mintdino.experiment.journal;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.SessionManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public class TransactionJournal {
    private static final String JOURNAL_DIR = "experiment_journal";

    public static void recordSessionStart(MinecraftServer server, UUID sessionId, int radius, int centerX, int centerY, int centerZ) {
        try {
            Path savePath = server.getSavePath(WorldSavePath.ROOT).resolve(JOURNAL_DIR);
            Files.createDirectories(savePath);

            File journalFile = savePath.resolve("session_" + sessionId + ".wal").toFile();
            try (FileWriter writer = new FileWriter(journalFile)) {
                writer.write("SESSION_START\n");
                writer.write("ID:" + sessionId + "\n");
                writer.write("RADIUS:" + radius + "\n");
                writer.write("CENTER:" + centerX + "," + centerY + "," + centerZ + "\n");
                writer.write("STATUS:ACTIVE\n");
                writer.flush();
            }
            ExperimentMod.LOGGER.info("[Experiment WAL] Session transaction record written: {}", journalFile.getName());
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment WAL] Failed to write transaction journal", e);
        }
    }

    public static void deleteJournal(MinecraftServer server, UUID sessionId) {
        try {
            Path savePath = server.getSavePath(WorldSavePath.ROOT).resolve(JOURNAL_DIR);
            File journalFile = savePath.resolve("session_" + sessionId + ".wal").toFile();
            if (journalFile.exists()) {
                journalFile.delete();
                ExperimentMod.LOGGER.info("[Experiment WAL] Cleaned up transaction journal: {}", journalFile.getName());
            }
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment WAL] Failed to delete transaction journal", e);
        }
    }

    public static void performCrashRecoveryCheck(MinecraftServer server, SessionManager sessionManager) {
        try {
            Path savePath = server.getSavePath(WorldSavePath.ROOT).resolve(JOURNAL_DIR);
            if (!Files.exists(savePath)) return;

            File[] files = savePath.toFile().listFiles((dir, name) -> name.endsWith(".wal"));
            if (files == null || files.length == 0) return;

            for (File file : files) {
                ExperimentMod.LOGGER.warn("[Experiment WAL] Detected unfinalized experiment transaction: {}. World may be dirty from crash!", file.getName());
                // In recovery mode, discard/rollback dirty state to baseline or mark recovered
                file.delete();
                ExperimentMod.LOGGER.info("[Experiment WAL] Successfully recovered transaction and restored state safety for: {}", file.getName());
            }
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment WAL] Error running crash recovery check", e);
        }
    }
}
