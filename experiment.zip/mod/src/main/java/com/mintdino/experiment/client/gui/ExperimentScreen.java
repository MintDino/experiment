package com.mintdino.experiment.client.gui;

import com.mintdino.experiment.network.ExperimentNetworking;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class ExperimentScreen extends Screen {

    public ExperimentScreen() {
        super(Text.translatable("gui.experiment.title"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = this.height / 4;

        // Start Experiment Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§aStart Experiment (16m)"), button -> {
            ClientPlayNetworking.send(new ExperimentNetworking.StartPayload(16));
            this.close();
        }).dimensions(centerX - 100, startY, 200, 20).build());

        // Create Checkpoint Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§bCreate Checkpoint"), button -> {
            // Send checkpoint creation
            this.close();
        }).dimensions(centerX - 100, startY + 30, 200, 20).build());

        // Keep Changes (Commit) Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§2Keep Changes (Commit)"), button -> {
            if (this.client != null) {
                this.client.setScreen(new ConfirmActionScreen(true, this));
            }
        }).dimensions(centerX - 100, startY + 60, 200, 20).build());

        // Discard Changes Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§cDiscard & Revert World"), button -> {
            if (this.client != null) {
                this.client.setScreen(new ConfirmActionScreen(false, this));
            }
        }).dimensions(centerX - 100, startY + 90, 200, 20).build());

        // Close Button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> this.close())
                .dimensions(centerX - 100, startY + 130, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        // Header Title in Mint Dino Jade
        context.drawCenteredTextWithShadow(this.textRenderer, "§b§lEXPERIMENT §f— Temporary Sandbox Mode", this.width / 2, 20, 0x14B8A6);
        context.drawCenteredTextWithShadow(this.textRenderer, "§7Target: Minecraft Java Edition 26.3 | Author: Mint Dino", this.width / 2, 35, 0x94A3B8);
    }
}
