package com.mintdino.experiment.core;

import com.mintdino.experiment.config.ExperimentConfig;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class SessionManager {
    private final MinecraftServer server;
    private final ExperimentConfig config;
    private final Map<UUID, ExperimentSession> activeSessions = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> playerToSessionMap = new ConcurrentHashMap<>();

    public SessionManager(MinecraftServer server, ExperimentConfig config) {
        this.server = server;
        this.config = config;
    }

    public ExperimentSession startSession(ServerPlayerEntity host, int radius) {
        if (playerToSessionMap.containsKey(host.getUuid())) {
            return activeSessions.get(playerToSessionMap.get(host.getUuid()));
        }

        int clampedRadius = Math.min(Math.max(4, radius), config.getMaxRadius());
        int verticalRange = config.getDefaultVerticalRange();

        ServerWorld world = host.getServerWorld();
        BlockPos center = host.getBlockPos();

        ExperimentSession session = new ExperimentSession(
                host.getUuid(),
                host.getName().getString(),
                world,
                center,
                clampedRadius,
                verticalRange
        );

        activeSessions.put(session.getId(), session);
        playerToSessionMap.put(host.getUuid(), session.getId());

        return session;
    }

    public boolean commitSession(UUID sessionId, ServerPlayerEntity player) {
        ExperimentSession session = activeSessions.get(sessionId);
        if (session == null) return false;

        // Verify host authorization or server operator
        if (!session.getHostUuid().equals(player.getUuid()) && !player.hasPermissionLevel(2)) {
            return false;
        }

        boolean success = session.commit();
        if (success) {
            cleanupSession(session);
        }
        return success;
    }

    public boolean discardSession(UUID sessionId, ServerPlayerEntity player) {
        ExperimentSession session = activeSessions.get(sessionId);
        if (session == null) return false;

        if (!session.getHostUuid().equals(player.getUuid()) && !player.hasPermissionLevel(2)) {
            return false;
        }

        boolean success = session.discard();
        if (success) {
            cleanupSession(session);
        }
        return success;
    }

    public ExperimentSession getSessionByPlayer(UUID playerUuid) {
        UUID sessionId = playerToSessionMap.get(playerUuid);
        return sessionId != null ? activeSessions.get(sessionId) : null;
    }

    public ExperimentSession getSessionAt(ServerWorld world, BlockPos pos) {
        for (ExperimentSession session : activeSessions.values()) {
            if (session.getWorld().equals(world) && session.getRegion().contains(pos)) {
                return session;
            }
        }
        return null;
    }

    private void cleanupSession(ExperimentSession session) {
        for (UUID participant : session.getParticipants()) {
            playerToSessionMap.remove(participant);
        }
        activeSessions.remove(session.getId());
    }

    public void onServerShutdown() {
        for (ExperimentSession session : activeSessions.values()) {
            if (config.isAutoRollbackOnShutdown()) {
                session.discard();
            }
        }
        activeSessions.clear();
        playerToSessionMap.clear();
    }

    public void tick() {
        // Heartbeat / async validation
    }

    public Collection<ExperimentSession> getActiveSessions() {
        return activeSessions.values();
    }
}
