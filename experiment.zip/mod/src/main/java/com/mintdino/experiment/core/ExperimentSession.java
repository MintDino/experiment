package com.mintdino.experiment.core;

import com.mintdino.experiment.checkpoint.CheckpointManager;
import com.mintdino.experiment.commit.CommitEngine;
import com.mintdino.experiment.diff.DiffEngine;
import com.mintdino.experiment.diff.WorldDiff;
import com.mintdino.experiment.journal.TransactionJournal;
import com.mintdino.experiment.rollback.RollbackEngine;
import com.mintdino.experiment.snapshot.SnapshotEngine;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ExperimentSession {
    public enum State {
        ACTIVE,
        COMMITTED,
        DISCARDED,
        TERMINATED
    }

    private final UUID id;
    private final UUID hostUuid;
    private final String hostName;
    private final ServerWorld world;
    private final ExperimentRegion region;
    private final SnapshotEngine snapshotEngine;
    private final CheckpointManager checkpointManager;
    private final Set<UUID> participants = new HashSet<>();
    private final Instant startTime;
    private State state;

    public ExperimentSession(UUID hostUuid, String hostName, ServerWorld world, BlockPos center, int radius, int verticalRange) {
        this.id = UUID.randomUUID();
        this.hostUuid = hostUuid;
        this.hostName = hostName;
        this.world = world;
        this.region = new ExperimentRegion(world, center, radius, verticalRange);
        this.snapshotEngine = new SnapshotEngine(world, this.region);
        this.checkpointManager = new CheckpointManager(world, this.region, this.snapshotEngine);
        this.participants.add(hostUuid);
        this.startTime = Instant.now();
        this.state = State.ACTIVE;

        // Persist WAL transaction record
        TransactionJournal.recordSessionStart(world.getServer(), this.id, radius, center.getX(), center.getY(), center.getZ());
    }

    public boolean commit() {
        if (state != State.ACTIVE) return false;
        boolean success = CommitEngine.executeCommit(world, region, snapshotEngine, id);
        if (success) {
            this.state = State.COMMITTED;
        }
        return success;
    }

    public boolean discard() {
        if (state != State.ACTIVE) return false;
        boolean success = RollbackEngine.executeRollback(world, region, snapshotEngine);
        if (success) {
            this.state = State.DISCARDED;
            TransactionJournal.deleteJournal(world.getServer(), id);
        }
        return success;
    }

    public WorldDiff computeDiff() {
        return DiffEngine.computeDiff(world, region, snapshotEngine);
    }

    public void addParticipant(ServerPlayerEntity player) {
        participants.add(player.getUuid());
    }

    public void removeParticipant(ServerPlayerEntity player) {
        participants.remove(player.getUuid());
    }

    public boolean isParticipant(UUID uuid) {
        return participants.contains(uuid);
    }

    public UUID getId() {
        return id;
    }

    public UUID getHostUuid() {
        return hostUuid;
    }

    public String getHostName() {
        return hostName;
    }

    public ServerWorld getWorld() {
        return world;
    }

    public ExperimentRegion getRegion() {
        return region;
    }

    public SnapshotEngine getSnapshotEngine() {
        return snapshotEngine;
    }

    public CheckpointManager getCheckpointManager() {
        return checkpointManager;
    }

    public Set<UUID> getParticipants() {
        return participants;
    }

    public State getState() {
        return state;
    }

    public Instant getStartTime() {
        return startTime;
    }
}
