package com.mintdino.experiment.rollback;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentRegion;
import com.mintdino.experiment.snapshot.BlockSnapshot;
import com.mintdino.experiment.snapshot.EntitySnapshot;
import com.mintdino.experiment.snapshot.SnapshotEngine;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RollbackEngine {

    public static boolean executeRollback(ServerWorld world, ExperimentRegion region, SnapshotEngine snapshotEngine) {
        ExperimentMod.LOGGER.info("[Experiment] Executing authoritative rollback for region around {}", region.getCenter());

        try {
            // 1. Restore Blocks & BlockEntities
            Map<BlockPos, BlockSnapshot> originalBlocks = snapshotEngine.getOriginalBlocks();
            for (Map.Entry<BlockPos, BlockSnapshot> entry : originalBlocks.entrySet()) {
                BlockPos pos = entry.getKey();
                BlockSnapshot snapshot = entry.getValue();

                // Set block state
                world.setBlockState(pos, snapshot.getState(), Block.NOTIFY_ALL | Block.REDRAW_ON_MAIN_THREAD);

                // Restore BlockEntity if applicable
                if (snapshot.hasBlockEntity()) {
                    BlockEntity be = world.getBlockEntity(pos);
                    if (be != null && snapshot.getBlockEntityNbt() != null) {
                        be.read(snapshot.getBlockEntityNbt(), world.getRegistryManager());
                        be.markDirty();
                    }
                }
            }

            // 2. Remove any newly created entities (TNT, dropped items, mobs, projectiles)
            Map<UUID, EntitySnapshot> originalEntities = snapshotEngine.getOriginalEntities();
            List<Entity> currentEntities = world.getOtherEntities(null, region.getBoundingBox(), e -> !e.isPlayer());

            for (Entity entity : currentEntities) {
                if (!originalEntities.containsKey(entity.getUuid())) {
                    entity.discard();
                }
            }

            // 3. Restore any removed/killed entities or restore their original NBT/position
            for (Map.Entry<UUID, EntitySnapshot> entry : originalEntities.entrySet()) {
                UUID originalUuid = entry.getKey();
                EntitySnapshot entitySnapshot = entry.getValue();

                Entity existing = world.getEntity(originalUuid);
                if (existing != null) {
                    existing.readNbt(entitySnapshot.getNbt());
                    existing.teleport(world, entitySnapshot.getPos().x, entitySnapshot.getPos().y, entitySnapshot.getPos().z,
                            java.util.Collections.emptySet(), entitySnapshot.getYaw(), entitySnapshot.getPitch());
                } else {
                    // Respawn the entity if it was killed or removed
                    EntityType<?> type = entitySnapshot.getType();
                    Entity restored = type.create(world);
                    if (restored != null) {
                        restored.readNbt(entitySnapshot.getNbt());
                        restored.refreshPositionAndAngles(
                                entitySnapshot.getPos().x, entitySnapshot.getPos().y, entitySnapshot.getPos().z,
                                entitySnapshot.getYaw(), entitySnapshot.getPitch()
                        );
                        world.spawnEntity(restored);
                    }
                }
            }

            ExperimentMod.LOGGER.info("[Experiment] Rollback complete: restored {} blocks, processed {} entities",
                    originalBlocks.size(), originalEntities.size());
            return true;
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment] Error during rollback execution", e);
            return false;
        }
    }
}
