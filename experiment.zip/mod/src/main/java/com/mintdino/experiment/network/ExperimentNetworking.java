package com.mintdino.experiment.network;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentSession;
import com.mintdino.experiment.core.SessionManager;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.UUID;

public class ExperimentNetworking {

    // --- Payload Definitions ---
    public record StartPayload(int radius) implements CustomPayload {
        public static final Id<StartPayload> ID = new Id<>(Identifier.of("experiment", "c2s_start"));
        public static final PacketCodec<PacketByteBuf, StartPayload> CODEC = CustomPayload.codecOf(
                (payload, buf) -> buf.writeVarInt(payload.radius()),
                buf -> new StartPayload(buf.readVarInt())
        );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record CommitPayload(UUID sessionId) implements CustomPayload {
        public static final Id<CommitPayload> ID = new Id<>(Identifier.of("experiment", "c2s_commit"));
        public static final PacketCodec<PacketByteBuf, CommitPayload> CODEC = CustomPayload.codecOf(
                (payload, buf) -> buf.writeUuid(payload.sessionId()),
                buf -> new CommitPayload(buf.readUuid())
        );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record DiscardPayload(UUID sessionId) implements CustomPayload {
        public static final Id<DiscardPayload> ID = new Id<>(Identifier.of("experiment", "c2s_discard"));
        public static final PacketCodec<PacketByteBuf, DiscardPayload> CODEC = CustomPayload.codecOf(
                (payload, buf) -> buf.writeUuid(payload.sessionId()),
                buf -> new DiscardPayload(buf.readUuid())
        );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record CheckpointPayload(UUID sessionId, String checkpointName) implements CustomPayload {
        public static final Id<CheckpointPayload> ID = new Id<>(Identifier.of("experiment", "c2s_checkpoint"));
        public static final PacketCodec<PacketByteBuf, CheckpointPayload> CODEC = CustomPayload.codecOf(
                (payload, buf) -> {
                    buf.writeUuid(payload.sessionId());
                    buf.writeString(payload.checkpointName());
                },
                buf -> new CheckpointPayload(buf.readUuid(), buf.readString())
        );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public record RestorePayload(UUID sessionId, String checkpointName) implements CustomPayload {
        public static final Id<RestorePayload> ID = new Id<>(Identifier.of("experiment", "c2s_restore"));
        public static final PacketCodec<PacketByteBuf, RestorePayload> CODEC = CustomPayload.codecOf(
                (payload, buf) -> {
                    buf.writeUuid(payload.sessionId());
                    buf.writeString(payload.checkpointName());
                },
                buf -> new RestorePayload(buf.readUuid(), buf.readString())
        );
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public static void registerServerReceivers() {
        // Register C2S Codecs
        PayloadTypeRegistry.playC2S().register(StartPayload.ID, StartPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(CommitPayload.ID, CommitPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(DiscardPayload.ID, DiscardPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(CheckpointPayload.ID, CheckpointPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(RestorePayload.ID, RestorePayload.CODEC);

        // Server Handlers
        ServerPlayNetworking.registerGlobalReceiver(StartPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            context.server().execute(() -> {
                SessionManager manager = ExperimentMod.getInstance().getSessionManager();
                manager.startSession(player, payload.radius());
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(CommitPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            context.server().execute(() -> {
                SessionManager manager = ExperimentMod.getInstance().getSessionManager();
                manager.commitSession(payload.sessionId(), player);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(DiscardPayload.ID, (payload, context) -> {
            ServerPlayerEntity player = context.player();
            context.server().execute(() -> {
                SessionManager manager = ExperimentMod.getInstance().getSessionManager();
                manager.discardSession(payload.sessionId(), player);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(CheckpointPayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                SessionManager manager = ExperimentMod.getInstance().getSessionManager();
                ExperimentSession session = manager.getSessionByPlayer(context.player().getUuid());
                if (session != null && session.getId().equals(payload.sessionId())) {
                    session.getCheckpointManager().createCheckpoint(payload.checkpointName());
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(RestorePayload.ID, (payload, context) -> {
            context.server().execute(() -> {
                SessionManager manager = ExperimentMod.getInstance().getSessionManager();
                ExperimentSession session = manager.getSessionByPlayer(context.player().getUuid());
                if (session != null && session.getId().equals(payload.sessionId())) {
                    session.getCheckpointManager().restoreCheckpoint(payload.checkpointName());
                }
            });
        });
    }
}
