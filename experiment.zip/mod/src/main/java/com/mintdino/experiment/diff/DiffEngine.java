package com.mintdino.experiment.diff;

import com.mintdino.experiment.core.ExperimentRegion;
import com.mintdino.experiment.snapshot.BlockSnapshot;
import com.mintdino.experiment.snapshot.EntitySnapshot;
import com.mintdino.experiment.snapshot.SnapshotEngine;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.*;

public class DiffEngine {

    public static WorldDiff computeDiff(ServerWorld world, ExperimentRegion region, SnapshotEngine snapshotEngine) {
        Map<BlockPos, BlockSnapshot> modifiedBlocks = new HashMap<>(snapshotEngine.getOriginalBlocks());

        Map<UUID, EntitySnapshot> originalEntities = snapshotEngine.getOriginalEntities();
        List<Entity> currentEntities = world.getOtherEntities(null, region.getBoundingBox(), e -> !e.isPlayer());

        Set<UUID> currentUuids = new HashSet<>();
        List<UUID> spawnedEntities = new ArrayList<>();
        Map<UUID, EntitySnapshot> alteredEntities = new HashMap<>();

        for (Entity entity : currentEntities) {
            UUID id = entity.getUuid();
            currentUuids.add(id);
            if (!originalEntities.containsKey(id)) {
                spawnedEntities.add(id);
            } else {
                alteredEntities.put(id, originalEntities.get(id));
            }
        }

        List<UUID> removedEntities = new ArrayList<>();
        for (UUID originalId : originalEntities.keySet()) {
            if (!currentUuids.contains(originalId)) {
                removedEntities.add(originalId);
            }
        }

        return new WorldDiff(modifiedBlocks, spawnedEntities, removedEntities, alteredEntities);
    }
}
