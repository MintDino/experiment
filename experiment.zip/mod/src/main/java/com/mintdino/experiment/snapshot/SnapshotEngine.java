package com.mintdino.experiment.snapshot;

import com.mintdino.experiment.core.ExperimentRegion;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SnapshotEngine {
    private final ServerWorld world;
    private final ExperimentRegion region;
    
    // Baseline state captured lazily before first mutation
    private final Map<BlockPos, BlockSnapshot> originalBlocks = new ConcurrentHashMap<>();
    private final Map<UUID, EntitySnapshot> originalEntities = new ConcurrentHashMap<>();

    public SnapshotEngine(ServerWorld world, ExperimentRegion region) {
        this.world = world;
        this.region = region;
        captureEntitiesBaseline();
    }

    /**
     * Lazy capture: records the original block state if not already recorded.
     */
    public void captureBlockBeforeChange(BlockPos pos) {
        if (!region.contains(pos)) return;
        
        BlockPos immutablePos = pos.toImmutable();
        originalBlocks.computeIfAbsent(immutablePos, p -> {
            BlockState state = world.getBlockState(p);
            BlockEntity be = world.getBlockEntity(p);
            return new BlockSnapshot(p, state, be, world.getRegistryManager());
        });
    }

    /**
     * Initial capture of existing entities within the region.
     */
    private void captureEntitiesBaseline() {
        world.getOtherEntities(null, region.getBoundingBox(), entity -> !entity.isPlayer()).forEach(entity -> {
            originalEntities.put(entity.getUuid(), new EntitySnapshot(entity));
        });
    }

    public Map<BlockPos, BlockSnapshot> getOriginalBlocks() {
        return Collections.unmodifiableMap(originalBlocks);
    }

    public Map<UUID, EntitySnapshot> getOriginalEntities() {
        return Collections.unmodifiableMap(originalEntities);
    }

    public int getCapturedBlockCount() {
        return originalBlocks.size();
    }
}
