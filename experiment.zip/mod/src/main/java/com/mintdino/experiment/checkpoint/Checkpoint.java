package com.mintdino.experiment.checkpoint;

import com.mintdino.experiment.snapshot.BlockSnapshot;
import com.mintdino.experiment.snapshot.EntitySnapshot;
import net.minecraft.util.math.BlockPos;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

public class Checkpoint {
    private final String name;
    private final Instant createdAt;
    private final Map<BlockPos, BlockSnapshot> capturedBlocks;
    private final Map<UUID, EntitySnapshot> capturedEntities;

    public Checkpoint(String name, Map<BlockPos, BlockSnapshot> capturedBlocks, Map<UUID, EntitySnapshot> capturedEntities) {
        this.name = name;
        this.createdAt = Instant.now();
        this.capturedBlocks = Map.copyOf(capturedBlocks);
        this.capturedEntities = Map.copyOf(capturedEntities);
    }

    public String getName() {
        return name;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public Map<BlockPos, BlockSnapshot> getCapturedBlocks() {
        return capturedBlocks;
    }

    public Map<UUID, EntitySnapshot> getCapturedEntities() {
        return capturedEntities;
    }
}
