package com.mintdino.experiment.mixin;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentSession;
import com.mintdino.experiment.core.SessionManager;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.explosion.Explosion;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(Explosion.class)
public abstract class ExplosionMixin {

    @Shadow @Final private World world;
    @Shadow @Final private List<BlockPos> affectedBlocks;

    @Inject(method = "affectWorld", at = @At("HEAD"))
    private void onAffectWorld(boolean particles, CallbackInfo ci) {
        if (!(world instanceof ServerWorld serverWorld)) return;

        SessionManager sessionManager = ExperimentMod.getInstance().getSessionManager();
        if (sessionManager == null) return;

        for (BlockPos pos : this.affectedBlocks) {
            ExperimentSession session = sessionManager.getSessionAt(serverWorld, pos);
            if (session != null) {
                session.getSnapshotEngine().captureBlockBeforeChange(pos);
            }
        }
    }
}
