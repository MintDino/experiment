package com.mintdino.experiment.command;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentSession;
import com.mintdino.experiment.core.SessionManager;
import com.mintdino.experiment.diff.WorldDiff;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ExperimentCommand {

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("experiment")
            .then(CommandManager.literal("start")
                .executes(ctx -> startExperiment(ctx.getSource(), 16))
                .then(CommandManager.argument("radius", IntegerArgumentType.integer(4, 64))
                    .executes(ctx -> startExperiment(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "radius")))))
            .then(CommandManager.literal("commit")
                .executes(ctx -> commitExperiment(ctx.getSource())))
            .then(CommandManager.literal("discard")
                .executes(ctx -> discardExperiment(ctx.getSource())))
            .then(CommandManager.literal("checkpoint")
                .then(CommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> createCheckpoint(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
            .then(CommandManager.literal("restore")
                .then(CommandManager.argument("name", StringArgumentType.word())
                    .executes(ctx -> restoreCheckpoint(ctx.getSource(), StringArgumentType.getString(ctx, "name")))))
            .then(CommandManager.literal("info")
                .executes(ctx -> showInfo(ctx.getSource())))
        );
    }

    private static int startExperiment(ServerCommandSource source, int radius) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) {
            source.sendError(Text.literal("Command must be executed by a player."));
            return 0;
        }

        SessionManager manager = ExperimentMod.getInstance().getSessionManager();
        ExperimentSession session = manager.startSession(player, radius);

        source.sendFeedback(() -> Text.literal("§a[Experiment] §fSession started! Region radius: §e" + radius + " §fblocks. World changes are temporary."), false);
        return 1;
    }

    private static int commitExperiment(ServerCommandSource source) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) return 0;

        SessionManager manager = ExperimentMod.getInstance().getSessionManager();
        ExperimentSession session = manager.getSessionByPlayer(player.getUuid());

        if (session == null) {
            source.sendError(Text.literal("You are not currently in an active experiment."));
            return 0;
        }

        boolean success = manager.commitSession(session.getId(), player);
        if (success) {
            source.sendFeedback(() -> Text.literal("§2[Experiment] §aAll changes permanently committed to the real world!").formatted(Formatting.BOLD), true);
            return 1;
        } else {
            source.sendError(Text.literal("Failed to commit experiment or unauthorized."));
            return 0;
        }
    }

    private static int discardExperiment(ServerCommandSource source) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) return 0;

        SessionManager manager = ExperimentMod.getInstance().getSessionManager();
        ExperimentSession session = manager.getSessionByPlayer(player.getUuid());

        if (session == null) {
            source.sendError(Text.literal("You are not currently in an active experiment."));
            return 0;
        }

        boolean success = manager.discardSession(session.getId(), player);
        if (success) {
            source.sendFeedback(() -> Text.literal("§c[Experiment] §fChanges discarded! World safely reverted to baseline state.").formatted(Formatting.BOLD), true);
            return 1;
        } else {
            source.sendError(Text.literal("Failed to discard experiment or unauthorized."));
            return 0;
        }
    }

    private static int createCheckpoint(ServerCommandSource source, String name) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) return 0;

        SessionManager manager = ExperimentMod.getInstance().getSessionManager();
        ExperimentSession session = manager.getSessionByPlayer(player.getUuid());

        if (session == null) {
            source.sendError(Text.literal("No active experiment to checkpoint."));
            return 0;
        }

        session.getCheckpointManager().createCheckpoint(name);
        source.sendFeedback(() -> Text.literal("§b[Experiment] §fCreated checkpoint: §e" + name), false);
        return 1;
    }

    private static int restoreCheckpoint(ServerCommandSource source, String name) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) return 0;

        SessionManager manager = ExperimentMod.getInstance().getSessionManager();
        ExperimentSession session = manager.getSessionByPlayer(player.getUuid());

        if (session == null) {
            source.sendError(Text.literal("No active experiment found."));
            return 0;
        }

        boolean restored = session.getCheckpointManager().restoreCheckpoint(name);
        if (restored) {
            source.sendFeedback(() -> Text.literal("§b[Experiment] §fRestored world state to checkpoint: §e" + name), true);
            return 1;
        } else {
            source.sendError(Text.literal("Checkpoint not found: " + name));
            return 0;
        }
    }

    private static int showInfo(ServerCommandSource source) {
        ServerPlayerEntity player = source.getPlayer();
        if (player == null) return 0;

        SessionManager manager = ExperimentMod.getInstance().getSessionManager();
        ExperimentSession session = manager.getSessionByPlayer(player.getUuid());

        if (session == null) {
            source.sendFeedback(() -> Text.literal("§7[Experiment] No active session."), false);
            return 1;
        }

        WorldDiff diff = session.computeDiff();
        source.sendFeedback(() -> Text.literal("§a=== Experiment Session Info ==="), false);
        source.sendFeedback(() -> Text.literal("§fID: §7" + session.getId()), false);
        source.sendFeedback(() -> Text.literal("§fHost: §e" + session.getHostName()), false);
        source.sendFeedback(() -> Text.literal("§fRadius: §e" + session.getRegion().getRadius() + " blocks"), false);
        source.sendFeedback(() -> Text.literal("§fModified Blocks: §b" + diff.getModifiedBlocks().size()), false);
        source.sendFeedback(() -> Text.literal("§fSpawned Entities: §b" + diff.getSpawnedEntities().size()), false);
        source.sendFeedback(() -> Text.literal("§fRemoved Entities: §b" + diff.getRemovedEntities().size()), false);
        return 1;
    }
}
