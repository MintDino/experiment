package com.mintdino.experiment.core;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;

import java.util.HashSet;
import java.util.Set;

public class ExperimentRegion {
    private final World world;
    private final BlockPos center;
    private final int radius;
    private final int minY;
    private final int maxY;
    private final Box boundingBox;
    private final Set<ChunkPos> coveredChunks;

    public ExperimentRegion(World world, BlockPos center, int radius, int verticalRange) {
        this.world = world;
        this.center = center;
        this.radius = radius;
        this.minY = Math.max(world.getBottomY(), center.getY() - verticalRange);
        this.maxY = Math.min(world.getTopY(), center.getY() + verticalRange);

        this.boundingBox = new Box(
                center.getX() - radius, minY, center.getZ() - radius,
                center.getX() + radius + 1, maxY + 1, center.getZ() + radius + 1
        );

        this.coveredChunks = new HashSet<>();
        int minChunkX = (center.getX() - radius) >> 4;
        int maxChunkX = (center.getX() + radius) >> 4;
        int minChunkZ = (center.getZ() - radius) >> 4;
        int maxChunkZ = (center.getZ() + radius) >> 4;

        for (int cx = minChunkX; cx <= maxChunkX; cx++) {
            for (int cz = minChunkZ; cz <= maxChunkZ; cz++) {
                coveredChunks.add(new ChunkPos(cx, cz));
            }
        }
    }

    public boolean contains(BlockPos pos) {
        return pos.getX() >= center.getX() - radius && pos.getX() <= center.getX() + radius &&
               pos.getY() >= minY && pos.getY() <= maxY &&
               pos.getZ() >= center.getZ() - radius && pos.getZ() <= center.getZ() + radius;
    }

    public boolean contains(double x, double y, double z) {
        return boundingBox.contains(x, y, z);
    }

    public World getWorld() {
        return world;
    }

    public BlockPos getCenter() {
        return center;
    }

    public int getRadius() {
        return radius;
    }

    public Box getBoundingBox() {
        return boundingBox;
    }

    public Set<ChunkPos> getCoveredChunks() {
        return coveredChunks;
    }
}
