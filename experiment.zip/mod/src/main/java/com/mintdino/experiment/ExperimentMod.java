package com.mintdino.experiment;

import com.mintdino.experiment.command.ExperimentCommand;
import com.mintdino.experiment.config.ExperimentConfig;
import com.mintdino.experiment.core.SessionManager;
import com.mintdino.experiment.journal.TransactionJournal;
import com.mintdino.experiment.network.ExperimentNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExperimentMod implements ModInitializer {
    public static final String MOD_ID = "experiment";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ExperimentMod instance;
    private SessionManager sessionManager;
    private ExperimentConfig config;

    @Override
    public void onInitialize() {
        instance = this;
        LOGGER.info("[Experiment] Initializing authoritative sandbox & rollback engine by Mint Dino");

        // Load configuration
        this.config = ExperimentConfig.load();

        // Register custom networking payloads & channels
        ExperimentNetworking.registerServerReceivers();

        // Register commands
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            ExperimentCommand.register(dispatcher);
        });

        // Server lifecycle handling
        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            this.sessionManager = new SessionManager(server, this.config);
            // Check for crash recovery / unfinished transactions
            TransactionJournal.performCrashRecoveryCheck(server, this.sessionManager);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (this.sessionManager != null) {
                this.sessionManager.onServerShutdown();
            }
        });

        // Server tick events for session timeouts, async diff tracking, and sync
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (this.sessionManager != null) {
                this.sessionManager.tick();
            }
        });
    }

    public static ExperimentMod getInstance() {
        return instance;
    }

    public SessionManager getSessionManager() {
        return sessionManager;
    }

    public ExperimentConfig getConfig() {
        return config;
    }
}
