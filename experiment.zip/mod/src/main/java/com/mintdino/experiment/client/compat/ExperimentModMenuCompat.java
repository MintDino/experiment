package com.mintdino.experiment.client.compat;

import com.mintdino.experiment.client.gui.ExperimentConfigScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

public class ExperimentModMenuCompat implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parent -> new ExperimentConfigScreen(parent);
    }
}
