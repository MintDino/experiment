package com.mintdino.experiment.snapshot;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.math.BlockPos;

public class BlockSnapshot {
    private final BlockPos pos;
    private final BlockState state;
    private final NbtCompound blockEntityNbt;

    public BlockSnapshot(BlockPos pos, BlockState state, BlockEntity blockEntity, RegistryWrapper.WrapperLookup registries) {
        this.pos = pos.toImmutable();
        this.state = state;
        if (blockEntity != null) {
            this.blockEntityNbt = blockEntity.createNbtWithId(registries);
        } else {
            this.blockEntityNbt = null;
        }
    }

    public BlockPos getPos() {
        return pos;
    }

    public BlockState getState() {
        return state;
    }

    public NbtCompound getBlockEntityNbt() {
        return blockEntityNbt;
    }

    public boolean hasBlockEntity() {
        return blockEntityNbt != null;
    }
}
