package com.mintdino.experiment.snapshot;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.Vec3d;

import java.util.UUID;

public class EntitySnapshot {
    private final UUID uuid;
    private final EntityType<?> type;
    private final Vec3d pos;
    private final float yaw;
    private final float pitch;
    private final NbtCompound nbt;

    public EntitySnapshot(Entity entity) {
        this.uuid = entity.getUuid();
        this.type = entity.getType();
        this.pos = entity.getPos();
        this.yaw = entity.getYaw();
        this.pitch = entity.getPitch();

        this.nbt = new NbtCompound();
        entity.saveNbt(this.nbt);
    }

    public UUID getUuid() {
        return uuid;
    }

    public EntityType<?> getType() {
        return type;
    }

    public Vec3d getPos() {
        return pos;
    }

    public float getYaw() {
        return yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public NbtCompound getNbt() {
        return nbt;
    }
}
