package com.mintdino.experiment.checkpoint;

import com.mintdino.experiment.core.ExperimentRegion;
import com.mintdino.experiment.snapshot.BlockSnapshot;
import com.mintdino.experiment.snapshot.SnapshotEngine;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CheckpointManager {
    private final ServerWorld world;
    private final ExperimentRegion region;
    private final SnapshotEngine snapshotEngine;
    private final Map<String, Checkpoint> checkpoints = new ConcurrentHashMap<>();

    public CheckpointManager(ServerWorld world, ExperimentRegion region, SnapshotEngine snapshotEngine) {
        this.world = world;
        this.region = region;
        this.snapshotEngine = snapshotEngine;
    }

    public Checkpoint createCheckpoint(String name) {
        // Capture all currently modified blocks and entities
        Checkpoint checkpoint = new Checkpoint(name, snapshotEngine.getOriginalBlocks(), snapshotEngine.getOriginalEntities());
        checkpoints.put(name, checkpoint);
        return checkpoint;
    }

    public boolean restoreCheckpoint(String name) {
        Checkpoint checkpoint = checkpoints.get(name);
        if (checkpoint == null) return false;

        for (Map.Entry<BlockPos, BlockSnapshot> entry : checkpoint.getCapturedBlocks().entrySet()) {
            BlockPos pos = entry.getKey();
            BlockSnapshot snapshot = entry.getValue();

            world.setBlockState(pos, snapshot.getState(), Block.NOTIFY_ALL | Block.REDRAW_ON_MAIN_THREAD);
            if (snapshot.hasBlockEntity()) {
                BlockEntity be = world.getBlockEntity(pos);
                if (be != null && snapshot.getBlockEntityNbt() != null) {
                    be.read(snapshot.getBlockEntityNbt(), world.getRegistryManager());
                    be.markDirty();
                }
            }
        }
        return true;
    }

    public List<String> listCheckpoints() {
        return new ArrayList<>(checkpoints.keySet());
    }

    public int getCheckpointCount() {
        return checkpoints.size();
    }
}
