package com.mintdino.experiment.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.file.Path;

public class ExperimentConfig {
    private static final Logger LOGGER = LoggerFactory.getLogger("experiment-config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private int defaultRadius = 16;
    private int maxRadius = 64;
    private int defaultVerticalRange = 32;
    private int maxBlocksModified = 50000;
    private int maxEntitiesModified = 500;
    private int maxCheckpoints = 10;
    private boolean showHud = true;
    private boolean showConfirmationPrompts = true;
    private boolean autoRollbackOnShutdown = true;
    private boolean allowMultiplayerJoin = true;

    public static ExperimentConfig load() {
        try {
            Path configDir = FabricLoader.getInstance().getConfigDir();
            File configFile = configDir.resolve("experiment.json").toFile();

            if (configFile.exists()) {
                try (FileReader reader = new FileReader(configFile)) {
                    ExperimentConfig loaded = GSON.fromJson(reader, ExperimentConfig.class);
                    if (loaded != null) {
                        LOGGER.info("[Experiment] Loaded configuration from {}", configFile.getAbsolutePath());
                        return loaded;
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("[Experiment] Failed to load config, using defaults", e);
        }

        ExperimentConfig defaultConfig = new ExperimentConfig();
        defaultConfig.save();
        return defaultConfig;
    }

    public void save() {
        try {
            Path configDir = FabricLoader.getInstance().getConfigDir();
            File configFile = configDir.resolve("experiment.json").toFile();

            try (FileWriter writer = new FileWriter(configFile)) {
                GSON.toJson(this, writer);
            }
            LOGGER.info("[Experiment] Saved configuration to {}", configFile.getAbsolutePath());
        } catch (Exception e) {
            LOGGER.error("[Experiment] Failed to save config", e);
        }
    }

    public int getDefaultRadius() { return defaultRadius; }
    public void setDefaultRadius(int defaultRadius) { this.defaultRadius = defaultRadius; }

    public int getMaxRadius() { return maxRadius; }
    public void setMaxRadius(int maxRadius) { this.maxRadius = maxRadius; }

    public int getDefaultVerticalRange() { return defaultVerticalRange; }
    public void setDefaultVerticalRange(int defaultVerticalRange) { this.defaultVerticalRange = defaultVerticalRange; }

    public int getMaxBlocksModified() { return maxBlocksModified; }
    public void setMaxBlocksModified(int maxBlocksModified) { this.maxBlocksModified = maxBlocksModified; }

    public int getMaxEntitiesModified() { return maxEntitiesModified; }
    public void setMaxEntitiesModified(int maxEntitiesModified) { this.maxEntitiesModified = maxEntitiesModified; }

    public int getMaxCheckpoints() { return maxCheckpoints; }
    public void setMaxCheckpoints(int maxCheckpoints) { this.maxCheckpoints = maxCheckpoints; }

    public boolean isShowHud() { return showHud; }
    public void setShowHud(boolean showHud) { this.showHud = showHud; }

    public boolean isShowConfirmationPrompts() { return showConfirmationPrompts; }
    public void setShowConfirmationPrompts(boolean showConfirmationPrompts) { this.showConfirmationPrompts = showConfirmationPrompts; }

    public boolean isAutoRollbackOnShutdown() { return autoRollbackOnShutdown; }
    public void setAutoRollbackOnShutdown(boolean autoRollbackOnShutdown) { this.autoRollbackOnShutdown = autoRollbackOnShutdown; }

    public boolean isAllowMultiplayerJoin() { return allowMultiplayerJoin; }
    public void setAllowMultiplayerJoin(boolean allowMultiplayerJoin) { this.allowMultiplayerJoin = allowMultiplayerJoin; }
}
