package com.mintdino.experiment.commit;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentRegion;
import com.mintdino.experiment.journal.TransactionJournal;
import com.mintdino.experiment.snapshot.SnapshotEngine;
import net.minecraft.server.world.ServerWorld;

import java.util.UUID;

public class CommitEngine {

    public static boolean executeCommit(ServerWorld world, ExperimentRegion region, SnapshotEngine snapshotEngine, UUID sessionId) {
        ExperimentMod.LOGGER.info("[Experiment] Committing session {} changes permanently to real world", sessionId);

        try {
            // Remove recovery journal entry since changes are committed permanently
            TransactionJournal.deleteJournal(world.getServer(), sessionId);

            ExperimentMod.LOGGER.info("[Experiment] Session {} successfully finalized and committed", sessionId);
            return true;
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment] Error during commit execution", e);
            return false;
        }
    }
}
