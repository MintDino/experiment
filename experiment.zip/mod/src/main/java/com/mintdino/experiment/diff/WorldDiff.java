package com.mintdino.experiment.diff;

import com.mintdino.experiment.snapshot.BlockSnapshot;
import com.mintdino.experiment.snapshot.EntitySnapshot;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class WorldDiff {
    private final Map<BlockPos, BlockSnapshot> modifiedBlocks;
    private final List<UUID> spawnedEntities;
    private final List<UUID> removedEntities;
    private final Map<UUID, EntitySnapshot> alteredEntities;

    public WorldDiff(Map<BlockPos, BlockSnapshot> modifiedBlocks,
                     List<UUID> spawnedEntities,
                     List<UUID> removedEntities,
                     Map<UUID, EntitySnapshot> alteredEntities) {
        this.modifiedBlocks = modifiedBlocks;
        this.spawnedEntities = spawnedEntities;
        this.removedEntities = removedEntities;
        this.alteredEntities = alteredEntities;
    }

    public Map<BlockPos, BlockSnapshot> getModifiedBlocks() {
        return Collections.unmodifiableMap(modifiedBlocks);
    }

    public List<UUID> getSpawnedEntities() {
        return Collections.unmodifiableList(spawnedEntities);
    }

    public List<UUID> getRemovedEntities() {
        return Collections.unmodifiableList(removedEntities);
    }

    public Map<UUID, EntitySnapshot> getAlteredEntities() {
        return Collections.unmodifiableMap(alteredEntities);
    }

    public int getTotalChanges() {
        return modifiedBlocks.size() + spawnedEntities.size() + removedEntities.size() + alteredEntities.size();
    }
}
