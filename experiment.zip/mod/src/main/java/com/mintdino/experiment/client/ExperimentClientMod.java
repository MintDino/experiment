package com.mintdino.experiment.client;

import com.mintdino.experiment.client.gui.ExperimentScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public class ExperimentClientMod implements ClientModInitializer {
    public static KeyBinding openMenuKey;
    public static KeyBinding quickStartKey;
    public static KeyBinding quickCheckpointKey;
    public static KeyBinding quickCommitKey;
    public static KeyBinding quickDiscardKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.experiment.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_X,
                "category.experiment.keys"
        ));

        quickStartKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.experiment.start_session",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "category.experiment.keys"
        ));

        quickCheckpointKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.experiment.create_checkpoint",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "category.experiment.keys"
        ));

        quickCommitKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.experiment.commit",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "category.experiment.keys"
        ));

        quickDiscardKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.experiment.discard",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_UNKNOWN,
                "category.experiment.keys"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.player != null) {
                    client.setScreen(new ExperimentScreen());
                }
            }
        });
    }
}
