package com.mintdino.experiment.client.gui;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.config.ExperimentConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class ExperimentConfigScreen extends Screen {
    private final Screen parent;
    private final ExperimentConfig config;

    public ExperimentConfigScreen(Screen parent) {
        super(Text.literal("Experiment Configuration"));
        this.parent = parent;
        this.config = ExperimentMod.getInstance().getConfig();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = 45;

        // Radius setting button
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Default Radius: " + config.getDefaultRadius() + "m"),
                button -> {
                    int next = config.getDefaultRadius() == 16 ? 32 : config.getDefaultRadius() == 32 ? 64 : 16;
                    config.setDefaultRadius(next);
                    button.setMessage(Text.literal("Default Radius: " + next + "m"));
                    config.save();
                }
        ).dimensions(centerX - 100, startY, 200, 20).build());

        // Max Radius setting button
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Max Radius: " + config.getMaxRadius() + "m"),
                button -> {
                    int next = config.getMaxRadius() == 64 ? 128 : config.getMaxRadius() == 128 ? 32 : 64;
                    config.setMaxRadius(next);
                    button.setMessage(Text.literal("Max Radius: " + next + "m"));
                    config.save();
                }
        ).dimensions(centerX - 100, startY + 28, 200, 20).build());

        // Checkpoint Limit setting button
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Max Checkpoints: " + config.getMaxCheckpoints()),
                button -> {
                    int next = config.getMaxCheckpoints() == 10 ? 20 : config.getMaxCheckpoints() == 20 ? 5 : 10;
                    config.setMaxCheckpoints(next);
                    button.setMessage(Text.literal("Max Checkpoints: " + next));
                    config.save();
                }
        ).dimensions(centerX - 100, startY + 56, 200, 20).build());

        // Show HUD / Status Overlay
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Status HUD: " + (config.isShowHud() ? "§aEnabled" : "§cDisabled")),
                button -> {
                    boolean next = !config.isShowHud();
                    config.setShowHud(next);
                    button.setMessage(Text.literal("Status HUD: " + (next ? "§aEnabled" : "§cDisabled")));
                    config.save();
                }
        ).dimensions(centerX - 100, startY + 84, 200, 20).build());

        // Confirmation Prompts
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Confirm Actions: " + (config.isShowConfirmationPrompts() ? "§aEnabled" : "§cDisabled")),
                button -> {
                    boolean next = !config.isShowConfirmationPrompts();
                    config.setShowConfirmationPrompts(next);
                    button.setMessage(Text.literal("Confirm Actions: " + (next ? "§aEnabled" : "§cDisabled")));
                    config.save();
                }
        ).dimensions(centerX - 100, startY + 112, 200, 20).build());

        // Auto-Rollback on Shutdown
        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Auto-Rollback on Shutdown: " + (config.isAutoRollbackOnShutdown() ? "§aEnabled" : "§cDisabled")),
                button -> {
                    boolean next = !config.isAutoRollbackOnShutdown();
                    config.setAutoRollbackOnShutdown(next);
                    button.setMessage(Text.literal("Auto-Rollback on Shutdown: " + (next ? "§aEnabled" : "§cDisabled")));
                    config.save();
                }
        ).dimensions(centerX - 100, startY + 140, 200, 20).build());

        // Done button
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Done"), button -> {
            if (this.client != null) {
                this.client.setScreen(this.parent);
            }
        }).dimensions(centerX - 100, startY + 175, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, "§b§lExperiment Configuration", this.width / 2, 18, 0x14B8A6);
        context.drawCenteredTextWithShadow(this.textRenderer, "§7Changes persist to config/experiment.json", this.width / 2, 30, 0x94A3B8);
    }
}
