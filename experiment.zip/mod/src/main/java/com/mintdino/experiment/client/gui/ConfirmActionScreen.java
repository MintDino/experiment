package com.mintdino.experiment.client.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

@Environment(EnvType.CLIENT)
public class ConfirmActionScreen extends Screen {
    private final boolean isCommit;
    private final Screen parent;

    public ConfirmActionScreen(boolean isCommit, Screen parent) {
        super(Text.literal(isCommit ? "Confirm Commit" : "Confirm Discard"));
        this.isCommit = isCommit;
        this.parent = parent;
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        Text confirmText = isCommit ? Text.literal("§aYes, Keep Changes Permanently") : Text.literal("§cYes, Discard All & Rollback");
        this.addDrawableChild(ButtonWidget.builder(confirmText, button -> {
            if (this.client != null && this.client.player != null) {
                this.client.player.networkHandler.sendCommand(isCommit ? "experiment commit" : "experiment discard");
            }
            this.close();
        }).dimensions(centerX - 120, centerY + 30, 240, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), button -> {
            if (this.client != null) {
                this.client.setScreen(this.parent);
            }
        }).dimensions(centerX - 120, centerY + 60, 240, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        int centerX = this.width / 2;
        int centerY = this.height / 2;

        if (isCommit) {
            context.drawCenteredTextWithShadow(this.textRenderer, "§e§lConfirm Permanent Commit", centerX, centerY - 40, 0xFBBF24);
            context.drawCenteredTextWithShadow(this.textRenderer, "§7This will apply all changes permanently to your Minecraft world.", centerX, centerY - 25, 0xE2E8F0);
            context.drawCenteredTextWithShadow(this.textRenderer, "§7The baseline snapshot will be discarded.", centerX, centerY - 12, 0x94A3B8);
        } else {
            context.drawCenteredTextWithShadow(this.textRenderer, "§c§lConfirm World Rollback & Discard", centerX, centerY - 40, 0xF87171);
            context.drawCenteredTextWithShadow(this.textRenderer, "§7This will restore all blocks, containers, redstone, and mobs to their exact baseline.", centerX, centerY - 25, 0xE2E8F0);
            context.drawCenteredTextWithShadow(this.textRenderer, "§7Any explosions or broken blocks will be cleanly undone.", centerX, centerY - 12, 0x94A3B8);
        }
    }
}
