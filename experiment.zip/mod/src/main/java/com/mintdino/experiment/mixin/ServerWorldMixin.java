package com.mintdino.experiment.mixin;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentSession;
import com.mintdino.experiment.core.SessionManager;
import net.minecraft.block.BlockState;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ServerWorld.class)
public abstract class ServerWorldMixin {

    @Inject(method = "setBlockState(Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/BlockState;II)Z", at = @At("HEAD"))
    private void onSetBlockState(BlockPos pos, BlockState state, int flags, int maxUpdateDepth, CallbackInfoReturnable<Boolean> cir) {
        ServerWorld world = (ServerWorld) (Object) this;
        SessionManager sessionManager = ExperimentMod.getInstance().getSessionManager();
        if (sessionManager == null) return;

        ExperimentSession session = sessionManager.getSessionAt(world, pos);
        if (session != null) {
            session.getSnapshotEngine().captureBlockBeforeChange(pos);
        }
    }
}
