# Experiment — Minecraft Java Edition 26.3 Mod
**Author:** Mint Dino  
**Brand:** Mint Dino  
**License:** All Rights Reserved  
**Target Platform:** Minecraft Java Edition 26.3 (Fabric)  
**Fabric Loader:** >=0.18.2 | **Fabric API:** >=0.125.0+26.3  

---

## Overview

**Experiment** adds an authoritative, temporary sandbox mode to Minecraft Java Edition 26.3.  
While inside an active experiment session, world modifications are tracked with a non-destructive, lazy-snapshot architecture.

When the experiment ends, the player can choose:
* **KEEP CHANGES (Commit):** Permanently commit the final world state to disk.
* **DISCARD:** Instantaneously revert the world, inventories, entities, redstone, and fluids to their exact baseline before the experiment started.

---

## Core Features

- **Authoritative Snapshot Architecture:** Captures BlockStates, Block Entities (chests, furnaces, hoppers, shulkers), Inventories, Entity equipment/health/position, fluids, and scheduled ticks.
- **Server Authority & Multiplayer Safe:** Enforces server validation, boundary checks, and custom payload negotiation.
- **TNT & Explosion Protection:** Intercepts blast radiuses before destruction; complete rollback on discard.
- **Intermediate Checkpoints:** Save named snapshots during an experiment and restore them without terminating the session.
- **Crash Recovery & Write-Ahead Logging (WAL):** World modifications are treated as a transaction. If Minecraft crashes or loses power, the unfinalized transaction is detected and safely recovered on startup.
- **Minecraft-Native UI:** Aesthetic Mint Dino jade-accented HUD and screens with full keybind support.

---

## Commands

- `/experiment start [radius]` — Starts an experiment session (default radius: 16 blocks, max: 64 blocks).
- `/experiment commit` — Permanently applies changes to the real world.
- `/experiment discard` — Discards all temporary changes and reverts to baseline.
- `/experiment checkpoint <name>` — Creates a named checkpoint.
- `/experiment restore <name>` — Restores world state to the named checkpoint.
- `/experiment info` — Displays active session metrics and change counters.

---

## Installation

1. Install **Fabric Loader** (0.18.2+) for **Minecraft Java Edition 26.3**.
2. Download `fabric-api-0.125.0+26.3.jar` and place it into your `.minecraft/mods` folder.
3. Download `experiment-26.3-1.0.0.jar` and place it into your `.minecraft/mods` folder.
4. Launch Minecraft 26.3 and press `X` to open the Experiment Session Menu!
