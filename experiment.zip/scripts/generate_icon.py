#!/usr/bin/env python3
"""
Experiment Mod Icon Generator
Programmatically renders a high-definition Minecraft Java Edition mod icon (128x128).
Theme: Mint Dino Jade Blue / Mint (#10B981, #14B8A6, #2DD4BF, #0F766E) + Crisp White.
Symbolism: Isometric Minecraft voxel block enveloped by a sleek, dynamic rewind/rollback arrow.
"""

import math
import struct
import zlib
import os

WIDTH = 128
HEIGHT = 128

def create_icon():
    try:
        from PIL import Image, ImageDraw
        has_pil = True
    except ImportError:
        has_pil = False

    if has_pil:
        render_with_pil()
    else:
        render_with_pure_python()

def render_with_pil():
    from PIL import Image, ImageDraw

    # Super-sampling 4x for pristine anti-aliasing
    scale = 4
    w, h = WIDTH * scale, HEIGHT * scale
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # 1. Base Rounded Square with deep jade-teal gradient
    margin = 8 * scale
    r = 24 * scale
    bg_box = [margin, margin, w - margin, h - margin]
    draw.rounded_rectangle(bg_box, radius=r, fill=(7, 24, 27, 255), outline=(15, 118, 110, 255), width=2 * scale)

    # Subtle inner border glow
    inner_box = [margin + 3 * scale, margin + 3 * scale, w - margin - 3 * scale, h - margin - 3 * scale]
    draw.rounded_rectangle(inner_box, radius=r - 3 * scale, outline=(20, 184, 166, 80), width=1 * scale)

    # 2. Isometric Voxel Block in Center
    cx, cy = w // 2, h // 2 + 6 * scale
    s = 28 * scale # block half-radius
    h_s = int(s * 0.58)

    # Coordinates
    top_v = (cx, cy - s - h_s)
    right_v = (cx + s, cy - h_s // 2)
    left_v = (cx - s, cy - h_s // 2)
    center_v = (cx, cy)
    bottom_v = (cx, cy + s)
    bot_left_v = (cx - s, cy + h_s // 2)
    bot_right_v = (cx + s, cy + h_s // 2)

    # Top Face (Lush Bright Mint #2DD4BF to #10B981)
    draw.polygon([top_v, right_v, center_v, left_v], fill=(45, 212, 191, 255), outline=(94, 234, 212, 255))

    # Left Face (Medium Jade #0D9488)
    draw.polygon([left_v, center_v, bottom_v, bot_left_v], fill=(13, 148, 136, 255), outline=(20, 184, 166, 255))

    # Right Face (Deep Teal #0F766E)
    draw.polygon([center_v, right_v, bot_right_v, bottom_v], fill=(15, 118, 110, 255), outline=(17, 94, 89, 255))

    # Inner pixel grid on the voxel faces (Minecraft style grid)
    for i in range(1, 3):
        t = i / 3.0
        # Grid lines on left face
        p1 = (int(left_v[0] + (center_v[0] - left_v[0]) * t), int(left_v[1] + (center_v[1] - left_v[1]) * t))
        p2 = (int(bot_left_v[0] + (bottom_v[0] - bot_left_v[0]) * t), int(bot_left_v[1] + (bottom_v[1] - bot_left_v[1]) * t))
        draw.line([p1, p2], fill=(20, 184, 166, 120), width=1 * scale)

    # 3. Dynamic Rollback / Rewind Circular Arrow around the block
    arrow_radius = 42 * scale
    arc_cx, arc_cy = cx, cy - 2 * scale

    # Draw arc in segments for smooth color transition (White to Jade)
    num_points = 180
    start_angle = math.radians(45)
    end_angle = math.radians(330)

    arc_points = []
    for step in range(num_points):
        theta = start_angle + (end_angle - start_angle) * (step / float(num_points - 1))
        # Flattened isometric circle
        ax = arc_cx + arrow_radius * math.cos(theta)
        ay = arc_cy + (arrow_radius * 0.72) * math.sin(theta)
        arc_points.append((ax, ay))

    # Draw wide smooth arc
    for i in range(len(arc_points) - 1):
        progress = i / float(len(arc_points))
        # Color gradient: Mint Dino Jade (16, 185, 129) -> Pure White (255, 255, 255)
        r_c = int(16 + (255 - 16) * progress)
        g_c = int(185 + (255 - 185) * progress)
        b_c = int(129 + (255 - 129) * progress)
        draw.line([arc_points[i], arc_points[i+1]], fill=(r_c, g_c, b_c, 240), width=int(5.5 * scale))

    # Rewind Arrowhead at the end of the arc
    tip_x, tip_y = arc_points[0]
    head_size = 14 * scale

    # Triangle arrowhead pointing counter-clockwise
    p_tip = (tip_x + 3 * scale, tip_y - 2 * scale)
    p_left = (tip_x - head_size * 0.9, tip_y - head_size * 0.8)
    p_right = (tip_x - head_size * 0.2, tip_y + head_size * 0.9)
    draw.polygon([p_tip, p_left, p_right], fill=(255, 255, 255, 255), outline=(204, 251, 241, 255))

    # 4. Tiny sparkle particle accents (Jade / White)
    particles = [
        (cx - 38 * scale, cy - 30 * scale, 3 * scale, (255, 255, 255, 220)),
        (cx + 36 * scale, cy + 28 * scale, 2.5 * scale, (45, 212, 191, 200)),
        (cx + 40 * scale, cy - 24 * scale, 2 * scale, (167, 243, 208, 180)),
    ]
    for px, py, pr, pcolor in particles:
        draw.ellipse([px - pr, py - pr, px + pr, py + pr], fill=pcolor)

    # Downsample with Lanczos for anti-aliasing
    final_img = img.resize((WIDTH, HEIGHT), Image.Resampling.LANCZOS)

    save_destinations(final_img)

def render_with_pure_python():
    # Pure Python PNG fallback using zlib
    pixels = bytearray([0] * (WIDTH * HEIGHT * 4))

    for y in range(HEIGHT):
        for x in range(WIDTH):
            idx = (y * WIDTH + x) * 4
            # Background rounded rectangle
            dx = max(0, abs(x - WIDTH // 2) - (WIDTH // 2 - 12))
            dy = max(0, abs(y - HEIGHT // 2) - (HEIGHT // 2 - 12))
            dist = math.sqrt(dx * dx + dy * dy)

            if dist > 8:
                pixels[idx:idx+4] = [0, 0, 0, 0]
                continue

            # Default bg: Deep Jade-slate #07181B
            pixels[idx] = 7
            pixels[idx+1] = 24
            pixels[idx+2] = 27
            pixels[idx+3] = 255

            # Distance to center for block & ring
            cx, cy = WIDTH // 2, HEIGHT // 2 + 2
            rel_x = x - cx
            rel_y = y - cy

            # Rewind Ring (elliptical radius 34)
            ring_r = math.sqrt(rel_x * rel_x + (rel_y / 0.72) ** 2)
            if 30 <= ring_r <= 37:
                angle = math.atan2(rel_y, rel_x)
                if angle < math.radians(60) or angle > math.radians(-150):
                    # Mint to white color
                    t = (angle + math.pi) / (2 * math.pi)
                    pixels[idx] = int(20 + 235 * t)
                    pixels[idx+1] = int(184 + 71 * t)
                    pixels[idx+2] = int(166 + 89 * t)
                    pixels[idx+3] = 255

            # Simple isometric cube
            if abs(rel_x) < 18 and abs(rel_y) < 18:
                if rel_y < -rel_x * 0.5 and rel_y < rel_x * 0.5:
                    # Top face
                    pixels[idx] = 45
                    pixels[idx+1] = 212
                    pixels[idx+2] = 191
                    pixels[idx+3] = 255
                elif rel_x < 0:
                    # Left face
                    pixels[idx] = 13
                    pixels[idx+1] = 148
                    pixels[idx+2] = 136
                    pixels[idx+3] = 255
                else:
                    # Right face
                    pixels[idx] = 15
                    pixels[idx+1] = 118
                    pixels[idx+2] = 110
                    pixels[idx+3] = 255

    # Encode as PNG
    png_data = encode_png(WIDTH, HEIGHT, pixels)
    save_raw_png(png_data)

def encode_png(width, height, rgba_data):
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)

    raw = bytearray()
    for y in range(height):
        raw.append(0) # Filter type 0
        raw.extend(rgba_data[y * width * 4:(y + 1) * width * 4])

    compressed = zlib.compress(raw, 9)
    ihdr = struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', ihdr) + chunk(b'IDAT', compressed) + chunk(b'IEND', b'')

def save_destinations(pil_image):
    paths = [
        "/mod/src/main/resources/assets/experiment/icon.png",
        "/public/assets/experiment/icon.png",
        "/src/assets/icon.png"
    ]
    for p in paths:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        pil_image.save(p, "PNG")
        print(f"Saved icon to: {p}")

def save_raw_png(png_bytes):
    paths = [
        "/mod/src/main/resources/assets/experiment/icon.png",
        "/public/assets/experiment/icon.png",
        "/src/assets/icon.png"
    ]
    for p in paths:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as f:
            f.write(png_bytes)
        print(f"Saved pure PNG icon to: {p}")

if __name__ == "__main__":
    create_icon()
