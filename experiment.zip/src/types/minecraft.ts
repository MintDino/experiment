export type BlockType = 
  | 'stone' 
  | 'dirt' 
  | 'grass_block' 
  | 'oak_planks' 
  | 'diamond_block' 
  | 'emerald_block' 
  | 'obsidian' 
  | 'glass' 
  | 'tnt' 
  | 'chest' 
  | 'redstone_dust' 
  | 'lever' 
  | 'piston' 
  | 'water' 
  | 'lava';

export interface VoxelBlock {
  x: number;
  y: number;
  z: number;
  type: BlockType;
  metadata?: {
    powered?: boolean;
    extended?: boolean;
    inventory?: { name: string; count: number; icon: string }[];
    waterlogged?: boolean;
    level?: number;
  };
}

export type EntityType = 'sheep' | 'creeper' | 'villager' | 'minecart' | 'tnt_primed' | 'item_diamond';

export interface VoxelEntity {
  id: string;
  type: EntityType;
  x: number;
  y: number;
  z: number;
  health: number;
  maxHealth: number;
  name: string;
  isNew?: boolean;
}

export interface CheckpointRecord {
  id: string;
  name: string;
  timestamp: string;
  blockCount: number;
  entityCount: number;
  blocks: VoxelBlock[];
  entities: VoxelEntity[];
}

export interface DiffSummary {
  addedBlocks: number;
  removedBlocks: number;
  modifiedBlocks: number;
  spawnedEntities: number;
  removedEntities: number;
  inventoryTransfers: number;
}

export interface TestResult {
  id: string;
  name: string;
  category: 'Basic' | 'TNT' | 'Redstone' | 'Fluids' | 'Inventories' | 'Entities' | 'Checkpoints' | 'Chunking' | 'Multiplayer' | 'Recovery';
  description: string;
  status: 'idle' | 'running' | 'passed' | 'failed';
  durationMs?: number;
  baselineHash?: string;
  committedHash?: string;
  revertedHash?: string;
  log: string[];
}

export interface WalEntry {
  id: string;
  timestamp: string;
  type: 'SESSION_START' | 'DIRTY_CHUNK' | 'PRE_MUTATE_BLOCK' | 'CONTAINER_CAPTURE' | 'CHECKPOINT' | 'COMMITTED' | 'ROLLBACK';
  details: string;
}
