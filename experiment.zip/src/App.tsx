import React, { useState, useEffect } from 'react';
import { VoxelCanvas } from './components/VoxelCanvas';
import { TestMatrixRunner } from './components/TestMatrixRunner';
import { CodeExplorer } from './components/CodeExplorer';
import { CrashRecoveryView } from './components/CrashRecoveryView';
import { ArchitectAssistant } from './components/ArchitectAssistant';
import { InventoryModal } from './components/InventoryModal';
import { VoxelBlock, VoxelEntity, BlockType, CheckpointRecord, DiffSummary } from './types/minecraft';
import {
  Sparkles,
  Play,
  RotateCcw,
  Check,
  Bookmark,
  ShieldAlert,
  Layers,
  FileCode,
  CheckCircle2,
  BrainCircuit,
  Database,
  Flame,
  Box as BoxIcon,
  Pickaxe,
  Download,
  AlertOctagon,
  Users
} from 'lucide-react';
import confetti from 'canvas-confetti';

// Default World Baseline
const INITIAL_BLOCKS: VoxelBlock[] = [
  // 5x5 Stone Platform
  { x: -2, y: 0, z: -2, type: 'stone' },
  { x: -1, y: 0, z: -2, type: 'stone' },
  { x: 0, y: 0, z: -2, type: 'stone' },
  { x: 1, y: 0, z: -2, type: 'stone' },
  { x: 2, y: 0, z: -2, type: 'stone' },

  { x: -2, y: 0, z: -1, type: 'stone' },
  { x: -1, y: 0, z: -1, type: 'grass_block' },
  { x: 0, y: 0, z: -1, type: 'grass_block' },
  { x: 1, y: 0, z: -1, type: 'grass_block' },
  { x: 2, y: 0, z: -1, type: 'stone' },

  { x: -2, y: 0, z: 0, type: 'stone' },
  { x: -1, y: 0, z: 0, type: 'grass_block' },
  { x: 0, y: 0, z: 0, type: 'grass_block' },
  { x: 1, y: 0, z: 0, type: 'grass_block' },
  { x: 2, y: 0, z: 0, type: 'stone' },

  { x: -2, y: 0, z: 1, type: 'stone' },
  { x: -1, y: 0, z: 1, type: 'grass_block' },
  { x: 0, y: 0, z: 1, type: 'grass_block' },
  { x: 1, y: 0, z: 1, type: 'grass_block' },
  { x: 2, y: 0, z: 1, type: 'stone' },

  { x: -2, y: 0, z: 2, type: 'stone' },
  { x: -1, y: 0, z: 2, type: 'stone' },
  { x: 0, y: 0, z: 2, type: 'stone' },
  { x: 1, y: 0, z: 2, type: 'stone' },
  { x: 2, y: 0, z: 2, type: 'stone' },

  // Pre-built structures
  { x: -1, y: 1, z: -1, type: 'tnt' },
  { x: 1, y: 1, z: -1, type: 'tnt' },
  {
    x: 0,
    y: 1,
    z: -1,
    type: 'chest',
    metadata: {
      inventory: [
        { name: 'Diamond', count: 64, icon: '💎' },
        { name: 'Netherite Ingot', count: 16, icon: '⬛' },
        { name: 'Golden Apple', count: 8, icon: '🍎' }
      ]
    }
  },
  { x: -1, y: 1, z: 1, type: 'oak_planks' },
  { x: 0, y: 1, z: 1, type: 'diamond_block' },
  { x: 1, y: 1, z: 1, type: 'piston', metadata: { extended: false } },
  { x: 2, y: 1, z: 1, type: 'lever', metadata: { powered: false } },
];

const INITIAL_ENTITIES: VoxelEntity[] = [
  { id: 'sheep_1', type: 'sheep', x: -1, y: 1, z: 0, health: 8, maxHealth: 8, name: 'Sheep' },
  { id: 'creeper_1', type: 'creeper', x: 1, y: 1, z: 0, health: 20, maxHealth: 20, name: 'Creeper' },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'sandbox' | 'tests' | 'code' | 'wal' | 'architect'>('sandbox');

  // World State
  const [blocks, setBlocks] = useState<VoxelBlock[]>(INITIAL_BLOCKS);
  const [entities, setEntities] = useState<VoxelEntity[]>(INITIAL_ENTITIES);

  // Baseline Snapshot (saved on Start Experiment)
  const [baselineBlocks, setBaselineBlocks] = useState<VoxelBlock[]>(INITIAL_BLOCKS);
  const [baselineEntities, setBaselineEntities] = useState<VoxelEntity[]>(INITIAL_ENTITIES);

  // Session State
  const [isSessionActive, setIsSessionActive] = useState<boolean>(false);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [checkpoints, setCheckpoints] = useState<CheckpointRecord[]>([]);

  // Interaction Tools
  const [selectedTool, setSelectedTool] = useState<'inspect' | 'place' | 'break' | 'ignite'>('place');
  const [selectedBlockType, setSelectedBlockType] = useState<BlockType>('tnt');

  // Modals
  const [openChestBlock, setOpenChestBlock] = useState<VoxelBlock | null>(null);
  const [confirmDialog, setConfirmDialog] = useState<'commit' | 'discard' | null>(null);

  // Compute Live Diff Metrics
  const diffSummary: DiffSummary = {
    addedBlocks: blocks.filter((b) => !baselineBlocks.some((base) => base.x === b.x && base.y === b.y && base.z === b.z)).length,
    removedBlocks: baselineBlocks.filter((base) => !blocks.some((b) => b.x === base.x && b.y === base.y && b.z === base.z)).length,
    modifiedBlocks: blocks.filter((b) => {
      const base = baselineBlocks.find((bl) => bl.x === b.x && bl.y === b.y && bl.z === b.z);
      return base && (base.type !== b.type || JSON.stringify(base.metadata) !== JSON.stringify(b.metadata));
    }).length,
    spawnedEntities: entities.filter((e) => !baselineEntities.some((be) => be.id === e.id)).length,
    removedEntities: baselineEntities.filter((be) => !entities.some((e) => e.id === be.id)).length,
    inventoryTransfers: 0,
  };

  // Start Experiment Session
  const handleStartSession = () => {
    setBaselineBlocks(JSON.parse(JSON.stringify(blocks)));
    setBaselineEntities(JSON.parse(JSON.stringify(entities)));
    setIsSessionActive(true);
    setSessionId('exp_' + Math.random().toString(36).substring(2, 9));
    setCheckpoints([]);
  };

  // Commit (Keep Changes Permanently)
  const handleCommitSession = () => {
    setBaselineBlocks(JSON.parse(JSON.stringify(blocks)));
    setBaselineEntities(JSON.parse(JSON.stringify(entities)));
    setIsSessionActive(false);
    setSessionId(null);
    setConfirmDialog(null);
    confetti({ particleCount: 60, spread: 70, origin: { y: 0.6 } });
  };

  // Discard (Revert to Baseline)
  const handleDiscardSession = () => {
    setBlocks(JSON.parse(JSON.stringify(baselineBlocks)));
    setEntities(JSON.parse(JSON.stringify(baselineEntities)));
    setIsSessionActive(false);
    setSessionId(null);
    setConfirmDialog(null);
    confetti({ particleCount: 80, spread: 100, origin: { y: 0.6 }, colors: ['#10b981', '#14b8a6', '#06b6d4'] });
  };

  // Create Checkpoint
  const handleCreateCheckpoint = () => {
    const cpName = `Checkpoint #${checkpoints.length + 1}`;
    const newCp: CheckpointRecord = {
      id: 'cp_' + Date.now(),
      name: cpName,
      timestamp: new Date().toLocaleTimeString(),
      blockCount: blocks.length,
      entityCount: entities.length,
      blocks: JSON.parse(JSON.stringify(blocks)),
      entities: JSON.parse(JSON.stringify(entities))
    };
    setCheckpoints((prev) => [...prev, newCp]);
  };

  // Restore Checkpoint
  const handleRestoreCheckpoint = (cp: CheckpointRecord) => {
    setBlocks(JSON.parse(JSON.stringify(cp.blocks)));
    setEntities(JSON.parse(JSON.stringify(cp.entities)));
  };

  // Block Manipulation Handlers
  const handleBlockAdd = (block: VoxelBlock) => {
    setBlocks((prev) => {
      const filtered = prev.filter((b) => !(b.x === block.x && b.y === block.y && b.z === block.z));
      return [...filtered, block];
    });
  };

  const handleBlockRemove = (x: number, y: number, z: number) => {
    setBlocks((prev) => prev.filter((b) => !(b.x === x && b.y === y && b.z === z)));
  };

  // TNT Ignition & Blast Simulation
  const handleTntIgnite = (x: number, y: number, z: number) => {
    // 1. Destroy blocks within 2.5 block radius
    setTimeout(() => {
      setBlocks((prev) =>
        prev.filter((b) => {
          const dist = Math.sqrt(Math.pow(b.x - x, 2) + Math.pow(b.y - y, 2) + Math.pow(b.z - z, 2));
          return dist > 2.5;
        })
      );
      // Spawn particles / blast feedback
      confetti({
        particleCount: 50,
        spread: 90,
        origin: { y: 0.5 },
        colors: ['#ef4444', '#f97316', '#eab308']
      });
    }, 400);
  };

  // Toggle Lever & Piston
  const handleToggleLever = (x: number, y: number, z: number) => {
    setBlocks((prev) =>
      prev.map((b) => {
        if (b.x === x && b.y === y && b.z === z) {
          const newPowered = !b.metadata?.powered;
          return { ...b, metadata: { ...b.metadata, powered: newPowered } };
        }
        // If adjacent piston, extend or retract
        if (b.type === 'piston' && Math.abs(b.x - x) <= 1 && Math.abs(b.z - z) <= 1) {
          return { ...b, metadata: { ...b.metadata, extended: !b.metadata?.extended } };
        }
        return b;
      })
    );
  };

  const handleUpdateChestInventory = (x: number, y: number, z: number, items: any[]) => {
    setBlocks((prev) =>
      prev.map((b) => {
        if (b.x === x && b.y === y && b.z === z) {
          return { ...b, metadata: { ...b.metadata, inventory: items } };
        }
        return b;
      })
    );
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 font-sans overflow-hidden">
      {/* Top Navbar */}
      <header className="h-16 px-6 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between z-20 shrink-0">
        {/* Brand & Identity */}
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 via-teal-500 to-emerald-700 p-0.5 shadow-lg shadow-emerald-950/60 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <span className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-tr from-emerald-400 to-teal-200">
                E
              </span>
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2.5">
              <h1 className="text-base font-extrabold tracking-tight text-white flex items-center gap-2">
                EXPERIMENT
                <span className="text-[11px] font-mono font-bold px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-500/40 rounded-full">
                  Minecraft 26.3
                </span>
              </h1>
              <span className="text-xs px-2 py-0.5 bg-slate-800 text-slate-400 font-mono rounded">
                Fabric Loader 0.18.2
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">
              Brand: <strong className="text-emerald-400 font-semibold">Mint Dino</strong> • Temporary Sandbox & Authoritative Rollback Engine
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1.5 bg-slate-950/70 p-1 border border-slate-800 rounded-xl">
          <button
            onClick={() => setActiveTab('sandbox')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
              activeTab === 'sandbox'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <BoxIcon className="w-3.5 h-3.5" />
            3D Sandbox Simulator
          </button>
          <button
            onClick={() => setActiveTab('tests')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
              activeTab === 'tests'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            Integration Test Matrix
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
              activeTab === 'code'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            Fabric 26.3 Mod Source
          </button>
          <button
            onClick={() => setActiveTab('wal')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
              activeTab === 'wal'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            WAL & Crash Recovery
          </button>
          <button
            onClick={() => setActiveTab('architect')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all ${
              activeTab === 'architect'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-900/40'
                : 'text-purple-400 hover:text-purple-200 hover:bg-purple-950/40'
            }`}
          >
            <BrainCircuit className="w-3.5 h-3.5" />
            Gemini 3.1 Pro Thinking
          </button>
        </nav>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 p-4 overflow-hidden">
        {activeTab === 'sandbox' && (
          <div className="grid grid-cols-12 gap-4 h-full">
            {/* Left Column: 3D Voxel Viewport & Top Actions */}
            <div className="col-span-9 flex flex-col gap-3 h-full">
              {/* Session Control Toolbar */}
              <div className="flex items-center justify-between p-3 bg-slate-900/90 border border-slate-800 rounded-xl shadow-lg shrink-0">
                <div className="flex items-center gap-2.5">
                  {!isSessionActive ? (
                    <button
                      onClick={handleStartSession}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white rounded-lg shadow-lg shadow-emerald-950/60 transition-all flex items-center gap-2 active:scale-95"
                    >
                      <Play className="w-4 h-4 fill-current" />
                      Start Experiment (Radius: 16m)
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={handleCreateCheckpoint}
                        className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-cyan-300 border border-cyan-500/30 rounded-lg transition-all flex items-center gap-2 active:scale-95"
                      >
                        <Bookmark className="w-4 h-4" />
                        Save Checkpoint
                      </button>

                      <button
                        onClick={() => setConfirmDialog('commit')}
                        className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-xs font-bold text-white rounded-lg shadow-md shadow-teal-950/60 transition-all flex items-center gap-2 active:scale-95"
                      >
                        <Check className="w-4 h-4" />
                        Keep Changes (Commit)
                      </button>

                      <button
                        onClick={() => setConfirmDialog('discard')}
                        className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white rounded-lg shadow-md shadow-rose-950/60 transition-all flex items-center gap-2 active:scale-95 animate-pulse"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Discard & Rollback
                      </button>
                    </>
                  )}
                </div>

                {/* Diff Metric Counter */}
                <div className="flex items-center gap-4 text-xs font-mono">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span className="text-slate-500">Modified:</span>
                    <span className="font-bold text-amber-400">{diffSummary.modifiedBlocks}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span className="text-slate-500">Added:</span>
                    <span className="font-bold text-emerald-400">+{diffSummary.addedBlocks}</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span className="text-slate-500">Destroyed:</span>
                    <span className="font-bold text-rose-400">-{diffSummary.removedBlocks}</span>
                  </div>
                </div>
              </div>

              {/* 3D Canvas */}
              <div className="flex-1 min-h-0">
                <VoxelCanvas
                  blocks={blocks}
                  entities={entities}
                  isSessionActive={isSessionActive}
                  onBlockAdd={handleBlockAdd}
                  onBlockRemove={handleBlockRemove}
                  onTntIgnite={handleTntIgnite}
                  onChestOpen={(block) => setOpenChestBlock(block)}
                  onToggleLever={handleToggleLever}
                  selectedTool={selectedTool}
                  selectedBlockType={selectedBlockType}
                />
              </div>
            </div>

            {/* Right Column: Interaction Palette & Checkpoint Stack */}
            <div className="col-span-3 flex flex-col gap-3 h-full overflow-hidden">
              {/* Tool Selection Box */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-3 shrink-0">
                <span className="text-xs font-bold text-slate-300 block uppercase tracking-wider">
                  Interactive Tools
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setSelectedTool('place')}
                    className={`px-3 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                      selectedTool === 'place'
                        ? 'bg-emerald-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    <BoxIcon className="w-3.5 h-3.5" />
                    Place Block
                  </button>
                  <button
                    onClick={() => setSelectedTool('break')}
                    className={`px-3 py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                      selectedTool === 'break'
                        ? 'bg-rose-600 text-white shadow-md'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                    }`}
                  >
                    <Pickaxe className="w-3.5 h-3.5" />
                    Break Block
                  </button>
                  <button
                    onClick={() => setSelectedTool('ignite')}
                    className={`col-span-2 px-3 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-all ${
                      selectedTool === 'ignite'
                        ? 'bg-amber-600 text-white shadow-md'
                        : 'bg-slate-800 text-amber-400 hover:bg-slate-700'
                    }`}
                  >
                    <Flame className="w-4 h-4" />
                    Ignite TNT Blast
                  </button>
                </div>
              </div>

              {/* Block Palette */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-3.5 space-y-2.5 shrink-0">
                <span className="text-xs font-bold text-slate-300 block uppercase tracking-wider">
                  Block Palette
                </span>
                <div className="grid grid-cols-4 gap-1.5">
                  {[
                    { type: 'tnt', name: 'TNT', color: 'bg-red-600' },
                    { type: 'chest', name: 'Chest', color: 'bg-amber-700' },
                    { type: 'diamond_block', name: 'Diamond', color: 'bg-cyan-500' },
                    { type: 'redstone_dust', name: 'Redstone', color: 'bg-rose-700' },
                    { type: 'water', name: 'Water', color: 'bg-blue-600' },
                    { type: 'lava', name: 'Lava', color: 'bg-orange-600' },
                    { type: 'piston', name: 'Piston', color: 'bg-amber-800' },
                    { type: 'lever', name: 'Lever', color: 'bg-slate-500' },
                    { type: 'stone', name: 'Stone', color: 'bg-zinc-600' },
                    { type: 'grass_block', name: 'Grass', color: 'bg-emerald-600' },
                    { type: 'oak_planks', name: 'Planks', color: 'bg-amber-600' },
                    { type: 'obsidian', name: 'Obsidian', color: 'bg-indigo-950' },
                  ].map((b) => (
                    <button
                      key={b.type}
                      onClick={() => {
                        setSelectedBlockType(b.type as BlockType);
                        setSelectedTool('place');
                      }}
                      className={`p-2 rounded-lg text-[11px] font-mono flex flex-col items-center gap-1 border transition-all ${
                        selectedBlockType === b.type && selectedTool === 'place'
                          ? 'border-emerald-400 bg-slate-800 text-white shadow'
                          : 'border-slate-800 bg-slate-950/60 text-slate-400 hover:bg-slate-800'
                      }`}
                    >
                      <div className={`w-4 h-4 rounded-sm ${b.color}`} />
                      <span className="truncate w-full text-center">{b.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Checkpoint Stack */}
              <div className="flex-1 bg-slate-900 border border-slate-800 rounded-xl p-3.5 flex flex-col overflow-hidden">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                  <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Bookmark className="w-3.5 h-3.5 text-cyan-400" />
                    Checkpoints
                  </span>
                  <span className="text-[11px] font-mono text-slate-500">{checkpoints.length} saved</span>
                </div>

                <div className="flex-1 overflow-y-auto space-y-2 font-mono text-xs">
                  {checkpoints.length > 0 ? (
                    checkpoints.map((cp) => (
                      <div
                        key={cp.id}
                        className="p-2.5 bg-slate-950/70 border border-slate-800 rounded-lg flex items-center justify-between"
                      >
                        <div>
                          <div className="text-slate-200 font-semibold">{cp.name}</div>
                          <div className="text-[10px] text-slate-500">
                            {cp.timestamp} • {cp.blockCount} Blocks
                          </div>
                        </div>
                        <button
                          onClick={() => handleRestoreCheckpoint(cp)}
                          className="px-2.5 py-1 bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 text-[11px] font-bold rounded transition-colors"
                        >
                          Restore
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="text-slate-500 italic text-center py-6 text-xs">
                      {isSessionActive
                        ? 'Click "Save Checkpoint" to record an intermediate world state.'
                        : 'Start an experiment session to enable checkpoints.'}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'tests' && <TestMatrixRunner />}
        {activeTab === 'code' && <CodeExplorer />}
        {activeTab === 'wal' && (
          <CrashRecoveryView
            isSessionActive={isSessionActive}
            onSimulateCrash={() => {
              setIsSessionActive(false);
            }}
            onTriggerRecovery={() => {
              setBlocks(JSON.parse(JSON.stringify(baselineBlocks)));
              setEntities(JSON.parse(JSON.stringify(baselineEntities)));
              setIsSessionActive(false);
            }}
          />
        )}
        {activeTab === 'architect' && <ArchitectAssistant />}
      </main>

      {/* Chest Inventory Modal */}
      {openChestBlock && (
        <InventoryModal
          chestBlock={openChestBlock}
          onClose={() => setOpenChestBlock(null)}
          onUpdateInventory={handleUpdateChestInventory}
        />
      )}

      {/* Confirmation Dialogs for Commit / Discard */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4 font-mono">
          <div className="w-full max-w-md bg-slate-900 border-2 border-slate-700 rounded-xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              {confirmDialog === 'commit' ? (
                <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
              ) : (
                <div className="p-2 bg-rose-500/10 border border-rose-500/30 rounded-lg text-rose-400">
                  <AlertOctagon className="w-6 h-6" />
                </div>
              )}
              <div>
                <h3 className="text-base font-bold text-white">
                  {confirmDialog === 'commit' ? 'Confirm Permanent Commit' : 'Confirm Complete Discard'}
                </h3>
                <p className="text-xs text-slate-400">
                  Target: Minecraft Java Edition 26.3
                </p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-lg border border-slate-800">
              {confirmDialog === 'commit'
                ? 'Are you sure you want to commit all changes? The experimental changes (blocks, explosions, redstone modifications) will become permanent in your world, and the baseline rollback log will be released.'
                : 'Are you sure you want to discard all changes? All exploded blocks, broken containers, placed contraptions, and displaced mobs will be restored exactly to their original state prior to starting the session.'}
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setConfirmDialog(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-300 rounded-lg transition-colors"
              >
                Cancel
              </button>
              {confirmDialog === 'commit' ? (
                <button
                  onClick={handleCommitSession}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white rounded-lg shadow-lg shadow-emerald-900/30 transition-all"
                >
                  Yes, Keep Changes Permanently
                </button>
              ) : (
                <button
                  onClick={handleDiscardSession}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white rounded-lg shadow-lg shadow-rose-900/30 transition-all"
                >
                  Yes, Discard All & Rollback World
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
