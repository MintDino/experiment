import React, { useState } from 'react';
import { VoxelBlock } from '../types/minecraft';
import { X, ArrowRightLeft, Sparkles, ShieldCheck } from 'lucide-react';

interface InventoryModalProps {
  chestBlock: VoxelBlock;
  onClose: () => void;
  onUpdateInventory: (x: number, y: number, z: number, items: { name: string; count: number; icon: string }[]) => void;
}

export const InventoryModal: React.FC<InventoryModalProps> = ({ chestBlock, onClose, onUpdateInventory }) => {
  const initialItems = chestBlock.metadata?.inventory || [
    { name: 'Diamond', count: 64, icon: '💎' },
    { name: 'Netherite Ingot', count: 16, icon: '⬛' },
    { name: 'Emerald', count: 32, icon: '🟩' },
    { name: 'Golden Apple', count: 8, icon: '🍎' },
  ];

  const [slots, setSlots] = useState<{ name: string; count: number; icon: string }[]>(() => {
    const list = Array(27).fill(null);
    initialItems.forEach((item, index) => {
      if (index < 27) list[index] = item;
    });
    return list;
  });

  const handleTakeItem = (index: number) => {
    if (!slots[index]) return;
    const newSlots = [...slots];
    newSlots[index] = null as any;
    setSlots(newSlots);
    onUpdateInventory(chestBlock.x, chestBlock.y, chestBlock.z, newSlots.filter(Boolean));
  };

  const handleAddItem = (item: { name: string; count: number; icon: string }) => {
    const emptyIndex = slots.findIndex((s) => !s);
    if (emptyIndex === -1) return;
    const newSlots = [...slots];
    newSlots[emptyIndex] = item;
    setSlots(newSlots);
    onUpdateInventory(chestBlock.x, chestBlock.y, chestBlock.z, newSlots.filter(Boolean));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-lg bg-[#c6c6c6] text-[#3f3f3f] border-4 border-t-[#ffffff] border-l-[#ffffff] border-b-[#555555] border-r-[#555555] shadow-2xl p-4 font-mono select-none">
        {/* Header */}
        <div className="flex items-center justify-between border-b-2 border-[#555555] pb-2 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">📦</span>
            <span className="font-bold text-base tracking-wide text-[#3f3f3f]">
              Chest ({chestBlock.x}, {chestBlock.y}, {chestBlock.z})
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#888888] rounded text-[#3f3f3f] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-[#555555] mb-3">
          Click an item to take/extract it. World state and NBT tags are authoritatively recorded.
        </p>

        {/* 27-slot Chest Inventory Grid */}
        <div className="grid grid-cols-9 gap-1 bg-[#8b8b8b] p-2 border-2 border-t-[#373737] border-l-[#373737] border-b-[#ffffff] border-r-[#ffffff] mb-4">
          {slots.map((slot, index) => (
            <div
              key={index}
              onClick={() => handleTakeItem(index)}
              className="relative w-10 h-10 bg-[#8b8b8b] border-2 border-t-[#373737] border-l-[#373737] border-b-[#ffffff] border-r-[#ffffff] flex items-center justify-center hover:bg-[#a0a0a0] cursor-pointer transition-all active:scale-95"
            >
              {slot && (
                <>
                  <span className="text-lg">{slot.icon}</span>
                  <span className="absolute bottom-0 right-1 text-[11px] font-bold text-white drop-shadow-[0_1px_1px_rgba(0,0,0,0.9)]">
                    {slot.count}
                  </span>
                </>
              )}
            </div>
          ))}
        </div>

        {/* Quick Insert Palette for Testing */}
        <div className="bg-[#b0b0b0] p-3 border-2 border-[#888888] rounded mb-3">
          <span className="text-xs font-bold block mb-2 text-[#222222]">Simulate Player Transfer:</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleAddItem({ name: 'Diamond', count: 64, icon: '💎' })}
              className="px-2.5 py-1 text-xs bg-[#dddddd] border border-[#555555] hover:bg-white text-black font-semibold rounded active:translate-y-0.5"
            >
              +64 Diamonds
            </button>
            <button
              onClick={() => handleAddItem({ name: 'TNT', count: 16, icon: '🧨' })}
              className="px-2.5 py-1 text-xs bg-[#dddddd] border border-[#555555] hover:bg-white text-black font-semibold rounded active:translate-y-0.5"
            >
              +16 TNT
            </button>
            <button
              onClick={() => handleAddItem({ name: 'Redstone', count: 64, icon: '🔴' })}
              className="px-2.5 py-1 text-xs bg-[#dddddd] border border-[#555555] hover:bg-white text-black font-semibold rounded active:translate-y-0.5"
            >
              +64 Redstone
            </button>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-[#555555] pt-2">
          <div className="flex items-center gap-1.5 text-emerald-800 font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>NBT Snapshot Enabled</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-[#4f46e5] hover:bg-[#4338ca] text-white font-bold rounded shadow"
          >
            Close Container
          </button>
        </div>
      </div>
    </div>
  );
};
