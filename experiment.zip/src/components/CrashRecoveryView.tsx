import React, { useState } from 'react';
import { WalEntry } from '../types/minecraft';
import { AlertTriangle, PowerOff, RefreshCw, CheckCircle2, FileText, Database, ShieldAlert, Zap } from 'lucide-react';

interface CrashRecoveryViewProps {
  isSessionActive: boolean;
  onSimulateCrash: () => void;
  onTriggerRecovery: () => void;
}

const INITIAL_WAL_ENTRIES: WalEntry[] = [
  {
    id: 'wal_001',
    timestamp: '2026-09-27T02:00:10.120Z',
    type: 'SESSION_START',
    details: 'SESSION_ID: 4a2b9f10-7e18-4e89-8d82-c20e2e92c2a0 | RADIUS: 16 | CENTER: (0, 64, 0)',
  },
  {
    id: 'wal_002',
    timestamp: '2026-09-27T02:00:14.340Z',
    type: 'DIRTY_CHUNK',
    details: 'CHUNK_POS: [0, 0] marked dirty. Prior baseline archived to disk.',
  },
  {
    id: 'wal_003',
    timestamp: '2026-09-27T02:00:18.890Z',
    type: 'CONTAINER_CAPTURE',
    details: 'BLOCK_POS: (2, 64, 2) Chest container NBT serialized (32 diamonds, 16 netherite).',
  },
  {
    id: 'wal_004',
    timestamp: '2026-09-27T02:00:22.450Z',
    type: 'CHECKPOINT',
    details: 'CHECKPOINT_ID: cp_pre_blast | Captured 34 block snapshots.',
  }
];

export const CrashRecoveryView: React.FC<CrashRecoveryViewProps> = ({
  isSessionActive,
  onSimulateCrash,
  onTriggerRecovery,
}) => {
  const [entries, setEntries] = useState<WalEntry[]>(INITIAL_WAL_ENTRIES);
  const [serverState, setServerState] = useState<'running' | 'crashed' | 'recovered'>('running');
  const [recoveryLog, setRecoveryLog] = useState<string[]>([]);

  const handleCrash = () => {
    setServerState('crashed');
    setEntries((prev) => [
      ...prev,
      {
        id: `wal_${Date.now()}`,
        timestamp: new Date().toISOString(),
        type: 'DIRTY_CHUNK',
        details: 'CRASH INTERRUPTION: Server killed without closing session transaction marker!',
      }
    ]);
    onSimulateCrash();
  };

  const handleRecover = () => {
    setRecoveryLog([
      `[Server Boot] Scanning directory: <world>/experiment_journal/ ...`,
      `[WAL Detected] Found unfinalized file: session_4a2b9f10.wal`,
      `[Integrity Check] Transaction status: ACTIVE (Ungraceful shutdown detected)`,
      `[RollbackEngine] Loading pre-mutation baseline chunks [0,0], [0,1]...`,
      `[RollbackEngine] Reconstituting 34 BlockStates and container NBT...`,
      `[RollbackEngine] Purging orphaned dropped items and entity velocities...`,
      `[Cleanup] Deleted session_4a2b9f10.wal. World integrity 100% restored.`
    ]);
    setServerState('recovered');
    onTriggerRecovery();
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Top Header */}
      <div className="flex items-center justify-between p-4 bg-slate-950/80 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-amber-500/10 border border-amber-500/30 rounded-lg text-amber-400">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Write-Ahead Log (WAL) & Crash Recovery
              <span
                className={`text-xs px-2 py-0.5 rounded-full font-mono font-bold ${
                  serverState === 'running'
                    ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                    : serverState === 'crashed'
                    ? 'bg-rose-950 text-rose-300 border border-rose-500/30 animate-pulse'
                    : 'bg-cyan-950 text-cyan-300 border border-cyan-500/30'
                }`}
              >
                {serverState === 'running' && 'Server: Normal'}
                {serverState === 'crashed' && 'Server: Crashed / Dirty'}
                {serverState === 'recovered' && 'Server: Recovered'}
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Transactional journal at &lt;world&gt;/experiment_journal/session_*.wal
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {serverState !== 'crashed' ? (
            <button
              onClick={handleCrash}
              className="px-3.5 py-1.5 bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/40 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
            >
              <PowerOff className="w-3.5 h-3.5" />
              Simulate Server Crash / Kill
            </button>
          ) : (
            <button
              onClick={handleRecover}
              className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white rounded-lg shadow-lg shadow-emerald-900/30 transition-all flex items-center gap-2 animate-bounce"
            >
              <RefreshCw className="w-4 h-4" />
              Reboot & Replay Recovery WAL
            </button>
          )}
        </div>
      </div>

      {/* Main Panel */}
      <div className="grid grid-cols-12 flex-1 overflow-hidden">
        {/* Left: WAL Table */}
        <div className="col-span-7 border-r border-slate-800 p-4 overflow-y-auto space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 font-mono pb-2 border-b border-slate-800">
            <span>Transaction WAL Records</span>
            <span>{entries.length} Entries</span>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {entries.map((entry) => (
              <div
                key={entry.id}
                className="p-3 bg-slate-950/60 border border-slate-800/80 rounded-lg space-y-1 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between text-[11px]">
                  <span className="px-2 py-0.5 bg-slate-800 text-emerald-400 font-bold rounded">
                    {entry.type}
                  </span>
                  <span className="text-slate-500">{entry.timestamp.slice(11, 23)}</span>
                </div>
                <div className="text-slate-300 text-xs leading-relaxed">{entry.details}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Recovery Diagnostics Console */}
        <div className="col-span-5 flex flex-col bg-slate-950/60 p-4 overflow-hidden">
          <div className="flex items-center gap-2 text-xs font-mono text-slate-400 pb-2 border-b border-slate-800 mb-3">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>Crash Recovery Engine Status:</span>
          </div>

          {serverState === 'crashed' && (
            <div className="p-3 bg-rose-950/50 border border-rose-500/40 rounded-lg text-rose-200 text-xs mb-3 space-y-1">
              <div className="font-bold flex items-center gap-1.5 text-rose-300">
                <AlertTriangle className="w-4 h-4" />
                Unfinished Transaction Detected!
              </div>
              <p className="text-[11px] text-rose-300/80">
                The server closed abruptly while world mutations were active. On next boot, <code>TransactionJournal.performCrashRecoveryCheck()</code> will intercept and safely restore the baseline.
              </p>
            </div>
          )}

          {serverState === 'recovered' && (
            <div className="p-3 bg-emerald-950/50 border border-emerald-500/40 rounded-lg text-emerald-200 text-xs mb-3 space-y-1">
              <div className="font-bold flex items-center gap-1.5 text-emerald-300">
                <CheckCircle2 className="w-4 h-4" />
                Crash Recovery Succeeded
              </div>
              <p className="text-[11px] text-emerald-300/80">
                Transaction rolled back safely. Zero world corruption. Baseline hashes verified.
              </p>
            </div>
          )}

          <div className="flex-1 bg-black/80 rounded-lg border border-slate-800/80 p-3 font-mono text-[11px] overflow-y-auto space-y-1.5 text-slate-300">
            {recoveryLog.length > 0 ? (
              recoveryLog.map((line, idx) => (
                <div
                  key={idx}
                  className={
                    line.includes('100%') || line.includes('Succeeded')
                      ? 'text-emerald-400 font-bold'
                      : line.includes('Detected')
                      ? 'text-amber-400'
                      : 'text-slate-300'
                  }
                >
                  {line}
                </div>
              ))
            ) : (
              <div className="text-slate-500 italic py-6 text-center">
                Click "Simulate Server Crash / Kill" to trigger an ungraceful shutdown and test the recovery replay engine.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
