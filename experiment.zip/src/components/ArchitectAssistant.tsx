import React, { useState } from 'react';
import { BrainCircuit, Send, Sparkles, Loader2, Lightbulb, ShieldAlert, Cpu } from 'lucide-react';

const PRESET_QUERIES = [
  'Analyze double-chest NBT serialization during TNT blast in Minecraft 26.3',
  'Verify chunk boundary edge cases during fluid flow and chunk unload',
  'Evaluate multi-client packet synchronization and permission injection defense',
  'Design an optimal lazy-snapshot algorithm for large redstone contraptions',
];

export const ArchitectAssistant: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState<string | null>(null);
  const [thinkingSummary, setThinkingSummary] = useState<string | null>(null);

  const handleQuery = async (queryText: string) => {
    if (!queryText.trim()) return;
    setPrompt(queryText);
    setIsLoading(true);
    setResponse(null);
    setThinkingSummary(null);

    try {
      const res = await fetch('/api/architect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: queryText,
          context: {
            minecraftVersion: '26.3',
            modLoader: 'Fabric',
            loaderVersion: '0.18.2',
            fabricApiVersion: '0.125.0+26.3',
            features: ['Authoritative Snapshot', 'Rollback', 'Commit', 'WAL Crash Recovery', 'Multiplayer']
          }
        })
      });

      const data = await res.json();
      if (data.analysis) {
        setResponse(data.analysis);
        setThinkingSummary(data.thinkingSummary || 'High-reasoning verification complete.');
      } else {
        setResponse(data.error || 'Failed to analyze query.');
      }
    } catch (e: any) {
      setResponse(`Error connecting to server architect: ${e.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Top Header */}
      <div className="flex items-center justify-between p-4 bg-slate-950/80 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-500/10 border border-purple-500/30 rounded-lg text-purple-400">
            <BrainCircuit className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Gemini 3.1 Pro Architectural Intelligence
              <span className="text-xs px-2 py-0.5 bg-purple-950 text-purple-300 border border-purple-500/30 rounded-full font-mono font-bold">
                ThinkingLevel.HIGH
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Deep reasoning for Minecraft 26.3 Fabric internals, mixins & memory safety
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-purple-400 bg-purple-950/40 border border-purple-800/40 px-3 py-1.5 rounded-lg">
          <Cpu className="w-3.5 h-3.5" />
          <span>Model: gemini-3.1-pro-preview</span>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col p-4 overflow-hidden">
        {/* Preset query badges */}
        <div className="mb-3">
          <div className="text-xs font-semibold text-slate-400 mb-2 flex items-center gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
            <span>Preset Architectural Inquiries:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {PRESET_QUERIES.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleQuery(q)}
                disabled={isLoading}
                className="text-left text-xs bg-slate-800/70 hover:bg-slate-800 text-slate-300 border border-slate-700/60 rounded-lg px-3 py-1.5 transition-all hover:border-purple-500/40"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Response Box */}
        <div className="flex-1 bg-slate-950/80 border border-slate-800 rounded-xl p-4 overflow-y-auto mb-4 font-mono text-xs text-slate-300">
          {thinkingSummary && (
            <div className="mb-3 p-3 bg-purple-950/40 border border-purple-500/30 rounded-lg text-purple-300 flex items-start gap-2.5">
              <BrainCircuit className="w-4 h-4 shrink-0 mt-0.5 text-purple-400" />
              <div>
                <span className="font-bold block text-purple-200">High Thinking Chain-of-Thought Summary:</span>
                <span className="text-[11px] text-purple-300/90">{thinkingSummary}</span>
              </div>
            </div>
          )}

          {response ? (
            <div className="whitespace-pre-wrap leading-relaxed space-y-2">
              {response}
            </div>
          ) : isLoading ? (
            <div className="flex flex-col items-center justify-center h-full text-slate-400 space-y-3">
              <Loader2 className="w-6 h-6 animate-spin text-purple-400" />
              <div className="text-xs font-mono text-center">
                Engaging Gemini 3.1 Pro with High Thinking Level...
                <br />
                <span className="text-slate-500 text-[11px]">
                  Evaluating Yarn 26.3 mappings, mixin call injection, NBT serialization & WAL safety.
                </span>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-full text-slate-500 text-center italic">
              Select a preset query above or ask any architectural question about Minecraft 26.3 Fabric modding.
            </div>
          )}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleQuery(prompt);
          }}
          className="flex items-center gap-2"
        >
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Ask about Fabric mixin injections, NBT serialization, chunk loading safety in 26.3..."
            className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500 font-mono"
          />
          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-xs font-bold text-white rounded-lg shadow-lg shadow-purple-900/30 transition-all flex items-center gap-2"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            Analyze
          </button>
        </form>
      </div>
    </div>
  );
};
