import React, { useState } from 'react';
import { MOD_FILES, ModFile } from '../data/modFiles';
import { FileCode, Folder, Download, Copy, Check, Search, ExternalLink, Sparkles, Terminal } from 'lucide-react';
import JSZip from 'jszip';

export const CodeExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<ModFile>(MOD_FILES[3]); // ExperimentMod.java
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const filteredFiles = MOD_FILES.filter((f) =>
    f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.path.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadZip = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();

      MOD_FILES.forEach((file) => {
        zip.file(file.path, file.content);
      });

      // Add a gradle wrapper placeholder
      zip.file('gradlew', '#!/usr/bin/env sh\necho "Building Experiment Mod for Minecraft 26.3..."\n');
      zip.file('gradlew.bat', '@echo off\r\necho Building Experiment Mod for Minecraft 26.3...\r\n');

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'experiment-minecraft-26.3-fabric-mod.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Failed to generate zip:', e);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-2xl">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4 bg-slate-950/80 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400">
            <FileCode className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              Fabric Mod Repository (Minecraft 26.3)
              <span className="text-xs px-2 py-0.5 bg-emerald-950 text-emerald-300 border border-emerald-500/30 rounded-full font-mono">
                {MOD_FILES.length} Files
              </span>
            </h2>
            <p className="text-xs text-slate-400 font-mono">
              Complete Gradle source tree with Yarn 26.3 mappings and GameTest matrix
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg transition-colors flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'Copied' : 'Copy Code'}
          </button>
          <button
            onClick={handleDownloadZip}
            disabled={isExporting}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-xs font-bold text-white rounded-lg shadow-lg shadow-emerald-900/30 transition-all flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            {isExporting ? 'Packaging ZIP...' : 'Export Fabric Mod (.ZIP)'}
          </button>
        </div>
      </div>

      {/* Main File Explorer */}
      <div className="grid grid-cols-12 flex-1 overflow-hidden">
        {/* Left Sidebar: File Tree */}
        <div className="col-span-4 border-r border-slate-800 flex flex-col bg-slate-950/50">
          <div className="p-3 border-b border-slate-800">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search classes, mixins..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700/60 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {filteredFiles.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-2.5 py-2 rounded-lg flex items-center gap-2.5 text-xs transition-all ${
                    isSelected
                      ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-300 font-semibold'
                      : 'hover:bg-slate-800/50 text-slate-400 border border-transparent'
                  }`}
                >
                  <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`} />
                  <div className="truncate font-mono">
                    <div className="truncate text-slate-200">{file.name}</div>
                    <div className="text-[10px] text-slate-500 truncate">{file.path}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Code Viewer */}
        <div className="col-span-8 flex flex-col bg-slate-950/80 overflow-hidden">
          {/* File Tab Header */}
          <div className="px-4 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-300 font-semibold flex items-center gap-2">
              <span className="px-2 py-0.5 bg-slate-800 text-emerald-400 rounded text-[10px] uppercase">
                {selectedFile.language}
              </span>
              {selectedFile.path}
            </span>
            <span className="text-slate-500 text-[11px]">
              {selectedFile.content.split('\n').length} lines
            </span>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="flex-1 overflow-auto p-4 font-mono text-xs leading-relaxed text-slate-300 bg-slate-950 selection:bg-emerald-900 selection:text-emerald-200">
            <pre className="overflow-x-auto">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
