import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { VoxelBlock, VoxelEntity, BlockType } from '../types/minecraft';
import { Sparkles, Play, RotateCcw, Check, Flame, Box as BoxIcon, Eye, ShieldAlert, Package, Layers } from 'lucide-react';
import confetti from 'canvas-confetti';

interface VoxelCanvasProps {
  blocks: VoxelBlock[];
  entities: VoxelEntity[];
  isSessionActive: boolean;
  onBlockAdd: (block: VoxelBlock) => void;
  onBlockRemove: (x: number, y: number, z: number) => void;
  onTntIgnite: (x: number, y: number, z: number) => void;
  onChestOpen: (block: VoxelBlock) => void;
  onToggleLever: (x: number, y: number, z: number) => void;
  selectedTool: 'inspect' | 'place' | 'break' | 'ignite';
  selectedBlockType: BlockType;
}

export const VoxelCanvas: React.FC<VoxelCanvasProps> = ({
  blocks,
  entities,
  isSessionActive,
  onBlockAdd,
  onBlockRemove,
  onTntIgnite,
  onChestOpen,
  onToggleLever,
  selectedTool,
  selectedBlockType,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const controlsRef = useRef<OrbitControls | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const raycasterRef = useRef(new THREE.Raycaster());
  const mouseRef = useRef(new THREE.Vector2());

  const blockMeshesRef = useRef<Map<string, THREE.Mesh>>(new Map());
  const entityMeshesRef = useRef<Map<string, THREE.Group>>(new Map());
  const hologramBoxRef = useRef<THREE.LineSegments | null>(null);

  // Initialize Three.js scene
  useEffect(() => {
    if (!mountRef.current) return;
    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0f172a); // Slate-900 Minecraft twilight
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(14, 12, 16);
    camera.lookAt(0, 2, 0);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.target.set(0, 1, 0);
    controls.maxPolarAngle = Math.PI / 2 + 0.1; // Don't go too far under ground
    controlsRef.current = controls;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(15, 25, 20);
    dirLight.castShadow = true;
    dirLight.shadow.mapSize.width = 2048;
    dirLight.shadow.mapSize.height = 2048;
    scene.add(dirLight);

    const mintGlow = new THREE.PointLight(0x10b981, 1.5, 30);
    mintGlow.position.set(0, 8, 0);
    scene.add(mintGlow);

    // Bedrock / Ground Grid
    const gridHelper = new THREE.GridHelper(24, 24, 0x10b981, 0x1e293b);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // Animation loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      controls.update();

      // Pulsing effect for experiment boundary
      if (hologramBoxRef.current && isSessionActive) {
        const time = Date.now() * 0.003;
        const mat = hologramBoxRef.current.material as THREE.LineBasicMaterial;
        mat.opacity = 0.4 + 0.3 * Math.sin(time);
      }

      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      if (!mountRef.current || !renderer || !camera) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animationFrameId);
      renderer.dispose();
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update Hologram Bounding Box
  useEffect(() => {
    if (!sceneRef.current) return;
    if (hologramBoxRef.current) {
      sceneRef.current.remove(hologramBoxRef.current);
      hologramBoxRef.current = null;
    }

    if (isSessionActive) {
      // 16x16x16 bounding box in Mint Dino Jade
      const boxGeometry = new THREE.BoxGeometry(16, 12, 16);
      const edges = new THREE.EdgesGeometry(boxGeometry);
      const lineMaterial = new THREE.LineBasicMaterial({
        color: 0x10b981,
        transparent: true,
        opacity: 0.6,
        linewidth: 2,
      });
      const wireframe = new THREE.LineSegments(edges, lineMaterial);
      wireframe.position.set(0, 5, 0);
      sceneRef.current.add(wireframe);
      hologramBoxRef.current = wireframe;
    }
  }, [isSessionActive]);

  // Texture and Material generator for Minecraft blocks
  const getBlockMaterial = (type: BlockType, metadata?: any): THREE.Material | THREE.Material[] => {
    switch (type) {
      case 'grass_block':
        return [
          new THREE.MeshStandardMaterial({ color: 0x5b8731 }), // Right (dirt-grass)
          new THREE.MeshStandardMaterial({ color: 0x5b8731 }), // Left
          new THREE.MeshStandardMaterial({ color: 0x48bb78 }), // Top (lush green)
          new THREE.MeshStandardMaterial({ color: 0x78350f }), // Bottom (dirt)
          new THREE.MeshStandardMaterial({ color: 0x5b8731 }), // Front
          new THREE.MeshStandardMaterial({ color: 0x5b8731 }), // Back
        ];
      case 'stone':
        return new THREE.MeshStandardMaterial({ color: 0x71717a, roughness: 0.9 });
      case 'dirt':
        return new THREE.MeshStandardMaterial({ color: 0x78350f, roughness: 0.9 });
      case 'oak_planks':
        return new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.7 });
      case 'diamond_block':
        return new THREE.MeshStandardMaterial({ color: 0x22d3ee, metalness: 0.5, roughness: 0.2 });
      case 'emerald_block':
        return new THREE.MeshStandardMaterial({ color: 0x10b981, metalness: 0.4, roughness: 0.3 });
      case 'obsidian':
        return new THREE.MeshStandardMaterial({ color: 0x1e1b4b, roughness: 0.4 });
      case 'glass':
        return new THREE.MeshStandardMaterial({ color: 0x93c5fd, transparent: true, opacity: 0.4, roughness: 0.1 });
      case 'tnt':
        return [
          new THREE.MeshStandardMaterial({ color: 0xef4444 }), // sides red
          new THREE.MeshStandardMaterial({ color: 0xef4444 }),
          new THREE.MeshStandardMaterial({ color: 0xf8fafc }), // top fuse
          new THREE.MeshStandardMaterial({ color: 0xef4444 }),
          new THREE.MeshStandardMaterial({ color: 0xef4444 }),
          new THREE.MeshStandardMaterial({ color: 0xef4444 }),
        ];
      case 'chest':
        return new THREE.MeshStandardMaterial({ color: 0xb45309, roughness: 0.6 });
      case 'redstone_dust':
        return new THREE.MeshStandardMaterial({ color: metadata?.powered ? 0xff0000 : 0x7f1d1d, emissive: metadata?.powered ? 0xff2222 : 0x000000, emissiveIntensity: 0.6 });
      case 'lever':
        return new THREE.MeshStandardMaterial({ color: 0x94a3b8 });
      case 'piston':
        return new THREE.MeshStandardMaterial({ color: 0x78350f });
      case 'water':
        return new THREE.MeshStandardMaterial({ color: 0x3b82f6, transparent: true, opacity: 0.65, roughness: 0.1 });
      case 'lava':
        return new THREE.MeshStandardMaterial({ color: 0xf97316, emissive: 0xea580c, emissiveIntensity: 0.8 });
      default:
        return new THREE.MeshStandardMaterial({ color: 0x94a3b8 });
    }
  };

  // Synchronize Blocks into Three.js Scene
  useEffect(() => {
    if (!sceneRef.current) return;
    const scene = sceneRef.current;
    const currentMeshes = blockMeshesRef.current;
    const currentKeys = new Set<string>();

    blocks.forEach((block) => {
      const key = `${block.x}_${block.y}_${block.z}`;
      currentKeys.add(key);

      const existingMesh = currentMeshes.get(key);
      if (!existingMesh) {
        // Create new block mesh
        const geom = new THREE.BoxGeometry(1, 1, 1);
        const mat = getBlockMaterial(block.type, block.metadata);
        const mesh = new THREE.Mesh(geom, mat);
        mesh.position.set(block.x, block.y + 0.5, block.z);
        mesh.castShadow = true;
        mesh.receiveShadow = true;
        mesh.userData = { block };

        // If chest, add a small latch latch
        if (block.type === 'chest') {
          const latchGeom = new THREE.BoxGeometry(0.16, 0.24, 0.1);
          const latchMat = new THREE.MeshStandardMaterial({ color: 0xfacc15 });
          const latchMesh = new THREE.Mesh(latchGeom, latchMat);
          latchMesh.position.set(0, 0, 0.52);
          mesh.add(latchMesh);
        }

        scene.add(mesh);
        currentMeshes.set(key, mesh);
      } else {
        // If type changed
        if (existingMesh.userData.block.type !== block.type || existingMesh.userData.block.metadata?.powered !== block.metadata?.powered) {
          existingMesh.material = getBlockMaterial(block.type, block.metadata);
          existingMesh.userData = { block };
        }
      }
    });

    // Remove deleted blocks
    for (const [key, mesh] of currentMeshes.entries()) {
      if (!currentKeys.has(key)) {
        scene.remove(mesh);
        if (mesh.geometry) mesh.geometry.dispose();
        currentMeshes.delete(key);
      }
    }
  }, [blocks]);

  // Synchronize Entities into Three.js Scene
  useEffect(() => {
    if (!sceneRef.current) return;
    const scene = sceneRef.current;
    const currentMeshes = entityMeshesRef.current;
    const currentKeys = new Set<string>();

    entities.forEach((entity) => {
      currentKeys.add(entity.id);
      let group = currentMeshes.get(entity.id);

      if (!group) {
        group = new THREE.Group();
        group.position.set(entity.x, entity.y, entity.z);

        if (entity.type === 'sheep') {
          // White body + head
          const bodyGeom = new THREE.BoxGeometry(1.2, 0.8, 1.6);
          const bodyMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.9 });
          const body = new THREE.Mesh(bodyGeom, bodyMat);
          body.position.y = 0.8;
          group.add(body);

          const headGeom = new THREE.BoxGeometry(0.6, 0.6, 0.7);
          const headMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9 });
          const head = new THREE.Mesh(headGeom, headMat);
          head.position.set(0, 1.2, 0.9);
          group.add(head);
        } else if (entity.type === 'creeper') {
          const bodyGeom = new THREE.BoxGeometry(0.6, 1.4, 0.4);
          const bodyMat = new THREE.MeshStandardMaterial({ color: 0x16a34a, roughness: 0.8 });
          const body = new THREE.Mesh(bodyGeom, bodyMat);
          body.position.y = 1.0;
          group.add(body);

          const headGeom = new THREE.BoxGeometry(0.7, 0.7, 0.7);
          const headMat = new THREE.MeshStandardMaterial({ color: 0x15803d });
          const head = new THREE.Mesh(headGeom, headMat);
          head.position.y = 1.9;
          group.add(head);
        } else if (entity.type === 'minecart') {
          const cartGeom = new THREE.BoxGeometry(1.2, 0.6, 1.0);
          const cartMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7 });
          const cart = new THREE.Mesh(cartGeom, cartMat);
          cart.position.y = 0.3;
          group.add(cart);
        }

        scene.add(group);
        currentMeshes.set(entity.id, group);
      } else {
        group.position.set(entity.x, entity.y, entity.z);
      }
    });

    for (const [id, group] of currentMeshes.entries()) {
      if (!currentKeys.has(id)) {
        scene.remove(group);
        currentMeshes.delete(id);
      }
    }
  }, [entities]);

  // Click & Interaction Handling
  const handlePointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (event.button !== 0 && event.button !== 2) return; // Left or Right click
    if (!mountRef.current || !cameraRef.current || !sceneRef.current) return;

    const rect = mountRef.current.getBoundingClientRect();
    mouseRef.current.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    mouseRef.current.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
    const meshes = Array.from(blockMeshesRef.current.values());
    const intersects = raycasterRef.current.intersectObjects(meshes, true);

    if (intersects.length > 0) {
      const hit = intersects[0];
      // Find parent block mesh
      let hitMesh: THREE.Object3D | null = hit.object;
      while (hitMesh && !hitMesh.userData?.block && hitMesh.parent) {
        hitMesh = hitMesh.parent;
      }
      if (!hitMesh || !hitMesh.userData?.block) return;
      const clickedBlock: VoxelBlock = hitMesh.userData.block;

      // Handle Tools
      if (selectedTool === 'ignite' || (event.button === 0 && clickedBlock.type === 'tnt')) {
        // Ignite TNT
        onTntIgnite(clickedBlock.x, clickedBlock.y, clickedBlock.z);
        return;
      }

      if (clickedBlock.type === 'chest') {
        onChestOpen(clickedBlock);
        return;
      }

      if (clickedBlock.type === 'lever') {
        onToggleLever(clickedBlock.x, clickedBlock.y, clickedBlock.z);
        return;
      }

      if (selectedTool === 'break' || event.button === 2) {
        // Break block
        onBlockRemove(clickedBlock.x, clickedBlock.y, clickedBlock.z);
        return;
      }

      if (selectedTool === 'place' && hit.face) {
        // Place adjacent block
        const normal = hit.face.normal;
        const newX = clickedBlock.x + Math.round(normal.x);
        const newY = clickedBlock.y + Math.round(normal.y);
        const newZ = clickedBlock.z + Math.round(normal.z);

        onBlockAdd({
          x: newX,
          y: newY,
          z: newZ,
          type: selectedBlockType,
          metadata: selectedBlockType === 'chest' ? {
            inventory: [
              { name: 'Diamond', count: 64, icon: '💎' },
              { name: 'Netherite Ingot', count: 16, icon: '⬛' }
            ]
          } : undefined
        });
      }
    } else if (selectedTool === 'place') {
      // Place on floor grid
      const plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
      const target = new THREE.Vector3();
      raycasterRef.current.ray.intersectPlane(plane, target);
      if (target) {
        onBlockAdd({
          x: Math.round(target.x),
          y: 0,
          z: Math.round(target.z),
          type: selectedBlockType,
        });
      }
    }
  };

  return (
    <div className="relative w-full h-full select-none overflow-hidden rounded-xl border border-slate-700/60 bg-slate-950 shadow-2xl">
      {/* 3D Viewport */}
      <div
        ref={mountRef}
        onPointerDown={handlePointerDown}
        onContextMenu={(e) => e.preventDefault()}
        className="w-full h-full cursor-crosshair"
      />

      {/* Experiment Active Holographic Indicator Banner */}
      {isSessionActive && (
        <div className="absolute top-4 left-4 z-10 flex items-center gap-3 px-4 py-2 bg-emerald-950/80 backdrop-blur-md border border-emerald-500/50 rounded-lg shadow-lg shadow-emerald-950/50 animate-pulse">
          <span className="relative flex h-3 w-3">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
          </span>
          <div className="flex flex-col">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
              Active Experiment Mode (Minecraft 26.3)
            </span>
            <span className="text-[11px] text-slate-300 font-mono">
              Region: 16m radius • Non-destructive Sandbox
            </span>
          </div>
        </div>
      )}

      {/* Floating Viewport Legend & Controls */}
      <div className="absolute bottom-4 left-4 z-10 flex items-center gap-3 px-3 py-1.5 bg-slate-900/80 backdrop-blur-sm border border-slate-700/50 rounded-lg text-xs text-slate-400">
        <span>Left-click: Interact / Place</span>
        <span>•</span>
        <span>Right-click: Break</span>
        <span>•</span>
        <span>Drag: Orbit</span>
        <span>•</span>
        <span>Scroll: Zoom</span>
      </div>

      <div className="absolute top-4 right-4 z-10 flex items-center gap-2 px-3 py-1.5 bg-slate-900/80 backdrop-blur-sm border border-slate-700/50 rounded-lg text-xs font-mono text-emerald-400">
        <Sparkles className="w-3.5 h-3.5" />
        <span>Voxel Engine: 26.3-Loom</span>
      </div>
    </div>
  );
};
