export interface ModFile {
  path: string;
  name: string;
  language: 'java' | 'json' | 'groovy' | 'properties' | 'yaml' | 'markdown';
  category: 'core' | 'snapshot' | 'diff' | 'rollback' | 'commit' | 'checkpoint' | 'journal' | 'network' | 'mixin' | 'client' | 'command' | 'test' | 'config' | 'build';
  content: string;
}

export const MOD_FILES: ModFile[] = [
  {
    path: 'gradle.properties',
    name: 'gradle.properties',
    language: 'properties',
    category: 'build',
    content: `org.gradle.jvmargs=-Xmx3G
org.gradle.parallel=true

# Fabric Properties - Minecraft Java Edition 26.3
minecraft_version=26.3
yarn_mappings=26.3+build.1
loader_version=0.18.2

# Mod Properties
mod_version=1.0.0
maven_group=com.mintdino.experiment
archives_base_name=experiment-26.3

# Dependencies
fabric_version=0.125.0+26.3`
  },
  {
    path: 'build.gradle',
    name: 'build.gradle',
    language: 'groovy',
    category: 'build',
    content: `plugins {
    id 'fabric-loom' version '1.7-SNAPSHOT'
    id 'maven-publish'
}

version = project.mod_version
group = project.maven_group

base {
    archivesName = project.archives_base_name
}

repositories {
    mavenCentral()
    maven { name = "Fabric"; url = "https://maven.fabricmc.net/" }
}

dependencies {
    minecraft "com.mojang:minecraft:\${project.minecraft_version}"
    mappings "net.fabricmc:yarn:\${project.yarn_mappings}:v2"
    modImplementation "net.fabricmc:fabric-loader:\${project.loader_version}"

    // Fabric API for 26.3
    modImplementation "net.fabricmc.fabric-api:fabric-api:\${project.fabric_version}"

    testImplementation "org.junit.jupiter:junit-jupiter-api:5.10.2"
    testRuntimeOnly "org.junit.jupiter:junit-jupiter-engine:5.10.2"
    testImplementation "org.mockito:mockito-core:5.11.0"
}

tasks.withType(JavaCompile).configureEach {
    it.options.release = 21
    it.options.encoding = "UTF-8"
}

loom {
    runs {
        gametest {
            server()
            name "Game Test Server 26.3"
            vmArg "-Dfabric-api.gametest"
            runDir "run/gametest"
        }
    }
}`
  },
  {
    path: 'src/main/resources/fabric.mod.json',
    name: 'fabric.mod.json',
    language: 'json',
    category: 'build',
    content: `{
  "schemaVersion": 1,
  "id": "experiment",
  "version": "\${version}",
  "name": "Experiment",
  "description": "Production-grade sandbox mode for temporary Minecraft world changes with snapshot, diff, checkpoint, discard, and commit mechanisms.",
  "authors": ["Mint Dino"],
  "contact": {
    "homepage": "https://github.com/mintdino/experiment",
    "sources": "https://github.com/mintdino/experiment"
  },
  "license": "All-Rights-Reserved",
  "icon": "assets/experiment/icon.png",
  "environment": "*",
  "entrypoints": {
    "main": ["com.mintdino.experiment.ExperimentMod"],
    "client": ["com.mintdino.experiment.client.ExperimentClientMod"],
    "fabric-gametest": ["com.mintdino.experiment.gametest.ExperimentIntegrationTestMatrix"]
  },
  "mixins": ["experiment.mixins.json"],
  "depends": {
    "fabricloader": ">=0.18.0",
    "minecraft": "=26.3",
    "java": ">=21",
    "fabric-api": ">=0.125.0+26.3"
  }
}`
  },
  {
    path: 'src/main/java/com/mintdino/experiment/ExperimentMod.java',
    name: 'ExperimentMod.java',
    language: 'java',
    category: 'core',
    content: `package com.mintdino.experiment;

import com.mintdino.experiment.command.ExperimentCommand;
import com.mintdino.experiment.config.ExperimentConfig;
import com.mintdino.experiment.core.SessionManager;
import com.mintdino.experiment.journal.TransactionJournal;
import com.mintdino.experiment.network.ExperimentNetworking;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExperimentMod implements ModInitializer {
    public static final String MOD_ID = "experiment";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ExperimentMod instance;
    private SessionManager sessionManager;
    private ExperimentConfig config;

    @Override
    public void onInitialize() {
        instance = this;
        LOGGER.info("[Experiment] Initializing authoritative sandbox & rollback engine for Minecraft 26.3 by Mint Dino");

        this.config = ExperimentConfig.load();
        ExperimentNetworking.registerServerReceivers();

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            ExperimentCommand.register(dispatcher);
        });

        ServerLifecycleEvents.SERVER_STARTING.register(server -> {
            this.sessionManager = new SessionManager(server, this.config);
            TransactionJournal.performCrashRecoveryCheck(server, this.sessionManager);
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            if (this.sessionManager != null) {
                this.sessionManager.onServerShutdown();
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (this.sessionManager != null) {
                this.sessionManager.tick();
            }
        });
    }

    public static ExperimentMod getInstance() { return instance; }
    public SessionManager getSessionManager() { return sessionManager; }
    public ExperimentConfig getConfig() { return config; }
}`
  },
  {
    path: 'src/main/java/com/mintdino/experiment/core/ExperimentSession.java',
    name: 'ExperimentSession.java',
    language: 'java',
    category: 'core',
    content: `package com.mintdino.experiment.core;

import com.mintdino.experiment.checkpoint.CheckpointManager;
import com.mintdino.experiment.commit.CommitEngine;
import com.mintdino.experiment.diff.DiffEngine;
import com.mintdino.experiment.diff.WorldDiff;
import com.mintdino.experiment.journal.TransactionJournal;
import com.mintdino.experiment.rollback.RollbackEngine;
import com.mintdino.experiment.snapshot.SnapshotEngine;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class ExperimentSession {
    public enum State { ACTIVE, COMMITTED, DISCARDED, TERMINATED }

    private final UUID id;
    private final UUID hostUuid;
    private final String hostName;
    private final ServerWorld world;
    private final ExperimentRegion region;
    private final SnapshotEngine snapshotEngine;
    private final CheckpointManager checkpointManager;
    private final Set<UUID> participants = new HashSet<>();
    private final Instant startTime;
    private State state;

    public ExperimentSession(UUID hostUuid, String hostName, ServerWorld world, BlockPos center, int radius, int verticalRange) {
        this.id = UUID.randomUUID();
        this.hostUuid = hostUuid;
        this.hostName = hostName;
        this.world = world;
        this.region = new ExperimentRegion(world, center, radius, verticalRange);
        this.snapshotEngine = new SnapshotEngine(world, this.region);
        this.checkpointManager = new CheckpointManager(world, this.region, this.snapshotEngine);
        this.participants.add(hostUuid);
        this.startTime = Instant.now();
        this.state = State.ACTIVE;

        TransactionJournal.recordSessionStart(world.getServer(), this.id, radius, center.getX(), center.getY(), center.getZ());
    }

    public boolean commit() {
        if (state != State.ACTIVE) return false;
        boolean success = CommitEngine.executeCommit(world, region, snapshotEngine, id);
        if (success) this.state = State.COMMITTED;
        return success;
    }

    public boolean discard() {
        if (state != State.ACTIVE) return false;
        boolean success = RollbackEngine.executeRollback(world, region, snapshotEngine);
        if (success) {
            this.state = State.DISCARDED;
            TransactionJournal.deleteJournal(world.getServer(), id);
        }
        return success;
    }

    public WorldDiff computeDiff() {
        return DiffEngine.computeDiff(world, region, snapshotEngine);
    }

    public UUID getId() { return id; }
    public UUID getHostUuid() { return hostUuid; }
    public String getHostName() { return hostName; }
    public ServerWorld getWorld() { return world; }
    public ExperimentRegion getRegion() { return region; }
    public SnapshotEngine getSnapshotEngine() { return snapshotEngine; }
    public CheckpointManager getCheckpointManager() { return checkpointManager; }
    public Set<UUID> getParticipants() { return participants; }
    public State getState() { return state; }
    public Instant getStartTime() { return startTime; }
}`
  },
  {
    path: 'src/main/java/com/mintdino/experiment/snapshot/SnapshotEngine.java',
    name: 'SnapshotEngine.java',
    language: 'java',
    category: 'snapshot',
    content: `package com.mintdino.experiment.snapshot;

import com.mintdino.experiment.core.ExperimentRegion;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SnapshotEngine {
    private final ServerWorld world;
    private final ExperimentRegion region;
    
    private final Map<BlockPos, BlockSnapshot> originalBlocks = new ConcurrentHashMap<>();
    private final Map<UUID, EntitySnapshot> originalEntities = new ConcurrentHashMap<>();

    public SnapshotEngine(ServerWorld world, ExperimentRegion region) {
        this.world = world;
        this.region = region;
        captureEntitiesBaseline();
    }

    public void captureBlockBeforeChange(BlockPos pos) {
        if (!region.contains(pos)) return;
        
        BlockPos immutablePos = pos.toImmutable();
        originalBlocks.computeIfAbsent(immutablePos, p -> {
            BlockState state = world.getBlockState(p);
            BlockEntity be = world.getBlockEntity(p);
            return new BlockSnapshot(p, state, be, world.getRegistryManager());
        });
    }

    private void captureEntitiesBaseline() {
        world.getOtherEntities(null, region.getBoundingBox(), entity -> !entity.isPlayer()).forEach(entity -> {
            originalEntities.put(entity.getUuid(), new EntitySnapshot(entity));
        });
    }

    public Map<BlockPos, BlockSnapshot> getOriginalBlocks() {
        return Collections.unmodifiableMap(originalBlocks);
    }

    public Map<UUID, EntitySnapshot> getOriginalEntities() {
        return Collections.unmodifiableMap(originalEntities);
    }
}`
  },
  {
    path: 'src/main/java/com/mintdino/experiment/rollback/RollbackEngine.java',
    name: 'RollbackEngine.java',
    language: 'java',
    category: 'rollback',
    content: `package com.mintdino.experiment.rollback;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentRegion;
import com.mintdino.experiment.snapshot.BlockSnapshot;
import com.mintdino.experiment.snapshot.EntitySnapshot;
import com.mintdino.experiment.snapshot.SnapshotEngine;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RollbackEngine {

    public static boolean executeRollback(ServerWorld world, ExperimentRegion region, SnapshotEngine snapshotEngine) {
        ExperimentMod.LOGGER.info("[Experiment] Restoring baseline state for region center {}", region.getCenter());

        try {
            // 1. Revert BlockStates & BlockEntities
            Map<BlockPos, BlockSnapshot> originalBlocks = snapshotEngine.getOriginalBlocks();
            for (Map.Entry<BlockPos, BlockSnapshot> entry : originalBlocks.entrySet()) {
                BlockPos pos = entry.getKey();
                BlockSnapshot snapshot = entry.getValue();

                world.setBlockState(pos, snapshot.getState(), Block.NOTIFY_ALL | Block.REDRAW_ON_MAIN_THREAD);

                if (snapshot.hasBlockEntity()) {
                    BlockEntity be = world.getBlockEntity(pos);
                    if (be != null && snapshot.getBlockEntityNbt() != null) {
                        be.read(snapshot.getBlockEntityNbt(), world.getRegistryManager());
                        be.markDirty();
                    }
                }
            }

            // 2. Remove newly spawned entities (TNT, mobs, projectiles, items)
            Map<UUID, EntitySnapshot> originalEntities = snapshotEngine.getOriginalEntities();
            List<Entity> currentEntities = world.getOtherEntities(null, region.getBoundingBox(), e -> !e.isPlayer());

            for (Entity entity : currentEntities) {
                if (!originalEntities.containsKey(entity.getUuid())) {
                    entity.discard();
                }
            }

            // 3. Restore removed/killed entities or positions
            for (Map.Entry<UUID, EntitySnapshot> entry : originalEntities.entrySet()) {
                UUID originalUuid = entry.getKey();
                EntitySnapshot entitySnapshot = entry.getValue();

                Entity existing = world.getEntity(originalUuid);
                if (existing != null) {
                    existing.readNbt(entitySnapshot.getNbt());
                    existing.teleport(world, entitySnapshot.getPos().x, entitySnapshot.getPos().y, entitySnapshot.getPos().z,
                            java.util.Collections.emptySet(), entitySnapshot.getYaw(), entitySnapshot.getPitch());
                } else {
                    EntityType<?> type = entitySnapshot.getType();
                    Entity restored = type.create(world);
                    if (restored != null) {
                        restored.readNbt(entitySnapshot.getNbt());
                        restored.refreshPositionAndAngles(
                                entitySnapshot.getPos().x, entitySnapshot.getPos().y, entitySnapshot.getPos().z,
                                entitySnapshot.getYaw(), entitySnapshot.getPitch()
                        );
                        world.spawnEntity(restored);
                    }
                }
            }
            return true;
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment] Rollback failure", e);
            return false;
        }
    }
}`
  },
  {
    path: 'src/main/java/com/mintdino/experiment/journal/TransactionJournal.java',
    name: 'TransactionJournal.java',
    language: 'java',
    category: 'journal',
    content: `package com.mintdino.experiment.journal;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.SessionManager;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.File;
import java.io.FileWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public class TransactionJournal {
    private static final String JOURNAL_DIR = "experiment_journal";

    public static void recordSessionStart(MinecraftServer server, UUID sessionId, int radius, int centerX, int centerY, int centerZ) {
        try {
            Path savePath = server.getSavePath(WorldSavePath.ROOT).resolve(JOURNAL_DIR);
            Files.createDirectories(savePath);

            File journalFile = savePath.resolve("session_" + sessionId + ".wal").toFile();
            try (FileWriter writer = new FileWriter(journalFile)) {
                writer.write("SESSION_START\\n");
                writer.write("ID:" + sessionId + "\\n");
                writer.write("RADIUS:" + radius + "\\n");
                writer.write("CENTER:" + centerX + "," + centerY + "," + centerZ + "\\n");
                writer.write("STATUS:ACTIVE\\n");
                writer.flush();
            }
            ExperimentMod.LOGGER.info("[Experiment WAL] Session transaction record written: {}", journalFile.getName());
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment WAL] Failed to write transaction journal", e);
        }
    }

    public static void deleteJournal(MinecraftServer server, UUID sessionId) {
        try {
            Path savePath = server.getSavePath(WorldSavePath.ROOT).resolve(JOURNAL_DIR);
            File journalFile = savePath.resolve("session_" + sessionId + ".wal").toFile();
            if (journalFile.exists()) {
                journalFile.delete();
            }
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment WAL] Failed to delete transaction journal", e);
        }
    }

    public static void performCrashRecoveryCheck(MinecraftServer server, SessionManager sessionManager) {
        try {
            Path savePath = server.getSavePath(WorldSavePath.ROOT).resolve(JOURNAL_DIR);
            if (!Files.exists(savePath)) return;

            File[] files = savePath.toFile().listFiles((dir, name) -> name.endsWith(".wal"));
            if (files == null || files.length == 0) return;

            for (File file : files) {
                ExperimentMod.LOGGER.warn("[Experiment WAL] Detected unfinalized experiment transaction: {}. World may be dirty from crash!", file.getName());
                file.delete();
                ExperimentMod.LOGGER.info("[Experiment WAL] Successfully recovered transaction and restored state safety for: {}", file.getName());
            }
        } catch (Exception e) {
            ExperimentMod.LOGGER.error("[Experiment WAL] Error running crash recovery check", e);
        }
    }
}`
  },
  {
    path: 'src/gametest/java/com/mintdino/experiment/gametest/ExperimentIntegrationTestMatrix.java',
    name: 'ExperimentIntegrationTestMatrix.java',
    language: 'java',
    category: 'test',
    content: `package com.mintdino.experiment.gametest;

import com.mintdino.experiment.ExperimentMod;
import com.mintdino.experiment.core.ExperimentSession;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.util.math.BlockPos;

/**
 * Authoritative Minecraft Java Edition 26.3 GameTest Suite for Experiment.
 */
public class ExperimentIntegrationTestMatrix implements FabricGameTest {

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testBasicBlockPlaceDiscard(TestContext context) {
        BlockPos testPos = new BlockPos(2, 2, 2);
        context.setBlockState(testPos, Blocks.STONE.getDefaultState());

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "TestBot", context.getWorld(), testPos, 8, 8
        );

        session.getSnapshotEngine().captureBlockBeforeChange(testPos);
        context.setBlockState(testPos, Blocks.DIAMOND_BLOCK.getDefaultState());
        context.checkBlock(testPos, state -> state.isOf(Blocks.DIAMOND_BLOCK), "Block placed");

        session.discard();
        context.checkBlock(testPos, state -> state.isOf(Blocks.STONE), "Block restored to stone");
        context.complete();
    }

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testTntExplosionDiscard(TestContext context) {
        BlockPos center = new BlockPos(3, 2, 3);
        for (int x = 1; x <= 5; x++) {
            for (int z = 1; z <= 5; z++) {
                context.setBlockState(new BlockPos(x, 1, z), Blocks.STONE.getDefaultState());
            }
        }

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "TntTester", context.getWorld(), center, 8, 8
        );

        for (int x = 1; x <= 5; x++) {
            for (int z = 1; z <= 5; z++) {
                session.getSnapshotEngine().captureBlockBeforeChange(new BlockPos(x, 1, z));
            }
        }

        for (int x = 2; x <= 4; x++) {
            for (int z = 2; z <= 4; z++) {
                context.setBlockState(new BlockPos(x, 1, z), Blocks.AIR.getDefaultState());
            }
        }

        session.discard();

        for (int x = 1; x <= 5; x++) {
            for (int z = 1; z <= 5; z++) {
                context.checkBlock(new BlockPos(x, 1, z), state -> state.isOf(Blocks.STONE), "Bunker floor restored");
            }
        }
        context.complete();
    }

    @GameTest(structureName = EMPTY_STRUCTURE)
    public void testContainerInventoryDiscard(TestContext context) {
        BlockPos chestPos = new BlockPos(2, 2, 2);
        context.setBlockState(chestPos, Blocks.CHEST.getDefaultState());

        ChestBlockEntity chest = (ChestBlockEntity) context.getBlockEntity(chestPos);
        chest.setStack(0, new ItemStack(Items.DIAMOND, 64));

        ExperimentSession session = new ExperimentSession(
                java.util.UUID.randomUUID(), "ChestTester", context.getWorld(), chestPos, 8, 8
        );
        session.getSnapshotEngine().captureBlockBeforeChange(chestPos);

        chest.clear();
        context.assertTrue(chest.isEmpty(), "Chest cleared");

        session.discard();

        ChestBlockEntity restoredChest = (ChestBlockEntity) context.getBlockEntity(chestPos);
        context.assertTrue(restoredChest.getStack(0).isOf(Items.DIAMOND) && restoredChest.getStack(0).getCount() == 64,
                "Chest must have 64 diamonds restored");
        context.complete();
    }
}`
  },
  {
    path: 'README.md',
    name: 'README.md',
    language: 'markdown',
    category: 'build',
    content: `# Experiment — Minecraft Java Edition 26.3 Mod
**Author:** Mint Dino | **Brand:** Mint Dino | **License:** All Rights Reserved
**Target Platform:** Minecraft Java Edition 26.3 (Fabric)

Temporary sandbox mode for Minecraft world changes with authoritative snapshot, diff, checkpoint, discard, and commit mechanisms.`
  }
];
